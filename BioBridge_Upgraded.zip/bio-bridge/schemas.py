"""Pydantic models for every structured object in the pipeline.

Fields added in the research-quality upgrade all have defaults, so runs saved by the previous
version still load (legacy Critic output is migrated in Evaluation._migrate_legacy)."""
from __future__ import annotations

import re
from typing import Annotated, Literal, Optional

from pydantic import BaseModel, BeforeValidator, Field, field_validator, model_validator

from integrity import clean_arxiv_id, clean_doi

Label = Literal["promising", "promising_with_modifications", "speculative", "poorly_supported"]
LABEL_ORDER: list[str] = ["poorly_supported", "speculative", "promising_with_modifications", "promising"]
LABEL_TEXT = {
    "promising": "Promising",
    "promising_with_modifications": "Promising with modifications",
    "speculative": "Speculative",
    "poorly_supported": "Poorly supported",
}


def _score(v):
    f = float(v)  # ValueError/TypeError -> validation error
    return min(10.0, max(0.0, f))


Score = Annotated[float, BeforeValidator(_score)]


def _label(v):
    if isinstance(v, str):
        s = re.sub(r"[\s\-]+", "_", v.strip().lower())
        s = {"unsuitable": "poorly_supported", "promising_with_modification": "promising_with_modifications",
             "promising_with_changes": "promising_with_modifications"}.get(s, s)
        return s
    return v


# ---------------------------------------------------------------- Agent 1
class BridgeQuery(BaseModel):
    target_field: str = Field(min_length=2)
    keywords: list[str] = Field(min_length=1, max_length=8)
    search_query: str = Field(min_length=3)
    rationale: str = Field(min_length=10)
    mechanism_targeted: str = ""  # which objective / constraint / mechanism this query probes

    @field_validator("keywords")
    @classmethod
    def _clean_keywords(cls, v: list[str]) -> list[str]:
        cleaned = [k.strip() for k in v if k and k.strip()]
        if not cleaned:
            raise ValueError("keywords must contain at least one non-empty string")
        return cleaned


class Abstraction(BaseModel):
    source_field: str = "unspecified"
    objective: str = ""
    abstract_description: str = Field(min_length=20)  # domain-independent structure
    math_primitives: list[str] = Field(default_factory=list)
    mechanisms: list[str] = Field(default_factory=list)  # underlying mechanisms the problem involves
    variables: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    bridge_queries: list[BridgeQuery]

    @model_validator(mode="after")
    def _check_queries(self) -> "Abstraction":
        n = len(self.bridge_queries)
        if not 3 <= n <= 6:
            raise ValueError(f"3 to 6 research directions required, got {n}")
        qs = [re.sub(r"\W+", " ", q.search_query.lower()).strip() for q in self.bridge_queries]
        if len(set(qs)) != n:
            raise ValueError("each research direction needs a different search_query")
        return self


class AbstractionOut(Abstraction):
    """What Gemini must return: the new decomposition fields are mandatory."""

    objective: str = Field(min_length=10)
    math_primitives: list[str] = Field(min_length=1)
    mechanisms: list[str] = Field(min_length=1)
    variables: list[str] = Field(min_length=1)


# ---------------------------------------------------------------- Agent 2
class Paper(BaseModel):
    paper_id: str  # stable id, e.g. "arxiv:2101.00001" or "s2:<hash>"
    title: str
    abstract: str = ""
    authors: list[str] = Field(default_factory=list)
    year: Optional[int] = None
    source: Literal["arXiv", "Semantic Scholar"]
    url: str
    arxiv_id: str = ""
    doi: str = ""
    target_field: str = ""
    similarity_raw: Optional[float] = None  # cosine similarity in [-1, 1]; retrieval ranking only
    similarity_norm: Optional[float] = None
    text_basis: Literal["abstract"] = "abstract"  # only abstracts are retrieved, never full texts

    @field_validator("arxiv_id", mode="before")
    @classmethod
    def _arxiv(cls, v):
        return clean_arxiv_id(v)

    @field_validator("doi", mode="before")
    @classmethod
    def _doi(cls, v):
        return clean_doi(v)

    @field_validator("url")
    @classmethod
    def _url(cls, v: str) -> str:
        if not re.match(r"https?://\S+$", v or ""):
            raise ValueError("paper url must be an http(s) link")
        return v

    @field_validator("authors", mode="before")
    @classmethod
    def _authors(cls, v):
        seen, out = set(), []
        for a in v or []:
            a = " ".join(str(a).split())
            if a and a.lower() not in seen:
                seen.add(a.lower())
                out.append(a)
        return out[:60]

    def authors_short(self, n: int = 4) -> str:
        if not self.authors:
            return "Authors unavailable"
        shown = ", ".join(self.authors[:n])
        return shown + (" et al." if len(self.authors) > n else "")


# ---------------------------------------------------------------- Agent 3
class ConceptMapping(BaseModel):
    problem_concept: str
    paper_concept: str
    note: str = ""


class SourceClaim(BaseModel):
    """Something the PAPER says. `quote` must occur verbatim in the retrieved abstract (checked in Python)."""

    statement: str = Field(min_length=5)
    quote: str = Field(min_length=8)


class TransferRisk(BaseModel):
    risk: str
    mitigation: str = ""


class CriterionScores(BaseModel):
    objective_alignment: Score
    mechanism_alignment: Score
    constraint_compatibility: Score
    evidence_strength: Score
    adaptation_feasibility: Score


class CriticOut(BaseModel):
    """What Gemini returns for one paper."""

    # reported by the paper (each backed by a verbatim quote)
    paper_objective: Optional[SourceClaim] = None
    paper_method: Optional[SourceClaim] = None
    reported_findings: list[SourceClaim] = Field(default_factory=list)
    reported_limitations: list[SourceClaim] = Field(default_factory=list)
    # Bio-Bridge interpretation (AI-generated)
    mechanism_extracted: str = Field(min_length=10)
    shared_structure: str = Field(min_length=10)
    mappings: list[ConceptMapping] = Field(default_factory=list)
    what_transfers: list[str] = Field(default_factory=list)
    needs_modification: list[str] = Field(default_factory=list)
    differences: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    risks: list[TransferRisk] = Field(default_factory=list)
    scores: CriterionScores
    score_rationale: str = Field(min_length=10)
    main_uncertainty: str = Field(min_length=5)
    label: Annotated[Label, BeforeValidator(_label)]

    @model_validator(mode="after")
    def _needs_counterpoints(self) -> "CriticOut":
        if not (self.differences or self.risks):
            raise ValueError("list at least one difference or transfer risk; no analogy is perfect")
        return self


class Evaluation(CriticOut):
    """CriticOut after Python verification, plus Python-computed fields."""

    paper_id: str
    transferability_score: float = Field(ge=0, le=10)  # weighted from the five criteria, in Python
    score_reliable: bool = True  # False when almost nothing could be verified in the abstract
    score_notes: list[str] = Field(default_factory=list)  # caps/adjustments applied in Python
    verification_note: str = ""
    legacy: bool = False  # True for runs saved before the five-criteria Critic existed

    @model_validator(mode="before")
    @classmethod
    def _migrate_legacy(cls, d):
        if not isinstance(d, dict) or "scores" in d or "structural_score" not in d:
            return d
        s = float(d.get("structural_score") or 0)
        lab = {"promising": "promising", "speculative": "speculative", "unsuitable": "poorly_supported"}.get(
            d.get("recommendation"), "speculative")
        return {
            "paper_id": d.get("paper_id", ""),
            "mechanism_extracted": d.get("shared_structure") or "Not recorded in the earlier format.",
            "shared_structure": d.get("shared_structure") or "Not recorded in the earlier format.",
            "mappings": d.get("mappings", []),
            "what_transfers": d.get("why_it_might_work", []),
            "assumptions": d.get("assumptions", []),
            "risks": [{"risk": x} for x in d.get("limitations", [])] or [{"risk": "Not recorded."}],
            "scores": {k: s for k in ("objective_alignment", "mechanism_alignment", "constraint_compatibility",
                                      "evidence_strength", "adaptation_feasibility")},
            "score_rationale": "Saved with an earlier version that gave one overall structural score.",
            "main_uncertainty": "Not recorded in the earlier format.",
            "label": lab,
            "transferability_score": s,
            "score_reliable": False,
            "score_notes": ["Saved before the upgrade: no per-criterion breakdown or claim verification."],
            "legacy": True,
        }


# ---------------------------------------------------------------- Agent 4
class Experiment(BaseModel):
    name: str
    description: str
    baselines: list[str] = Field(default_factory=list)
    metrics: list[str] = Field(default_factory=list)


class Adaptation(BaseModel):
    reuse: list[str] = Field(default_factory=list)
    modify: list[str] = Field(default_factory=list)
    how_it_addresses_problem: str = ""


class ValidationPlan(BaseModel):
    baseline: str = ""
    metrics: list[str] = Field(default_factory=list)
    required_data: list[str] = Field(default_factory=list)
    failure_conditions: list[str] = Field(default_factory=list)


class ProposalBase(BaseModel):
    title: str
    executive_summary: str
    problem_and_structure: str
    selected_mechanism: str
    hypothesis: str
    methodology: list[str] = Field(default_factory=list)
    variables_and_updates: str = ""
    experiments: list[Experiment] = Field(default_factory=list)
    expected_outcomes: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    limitations_and_assumptions: list[str] = Field(default_factory=list)
    cited_paper_ids: list[str] = Field(default_factory=list)
    adaptation: Optional[Adaptation] = None
    validation_plan: Optional[ValidationPlan] = None
    evidence_statement: str = ""


class ProposalOut(ProposalBase):
    """What Gemini returns. Citations are ids only; references are rebuilt in Python."""

    methodology: list[str] = Field(min_length=1)
    experiments: list[Experiment] = Field(default_factory=list, max_length=3)
    expected_outcomes: list[str] = Field(min_length=1)
    risks: list[str] = Field(min_length=1)
    limitations_and_assumptions: list[str] = Field(min_length=1)
    adaptation: Adaptation
    validation_plan: ValidationPlan
    evidence_statement: str = Field(min_length=20)

    @model_validator(mode="after")
    def _plan_complete(self) -> "ProposalOut":
        vp = self.validation_plan
        if not (vp.baseline.strip() and vp.metrics and vp.failure_conditions):
            raise ValueError("validation_plan needs a baseline, metrics and failure_conditions")
        return self


class Reference(BaseModel):
    paper_id: str
    title: str
    year: Optional[int] = None
    url: str
    source: str
    authors: list[str] = Field(default_factory=list)
    doi: str = ""
    arxiv_id: str = ""


class Proposal(ProposalBase):
    references: list[Reference] = Field(default_factory=list)
    dropped_citations: list[str] = Field(default_factory=list)
    evidence_basis: str = ""  # fixed statement written by Python, not by the model


# ---------------------------------------------------------------- Run result
class AgentStatus(BaseModel):
    name: str
    state: Literal["waiting", "running", "completed", "failed"] = "waiting"
    message: str = ""


class RunResult(BaseModel):
    problem: str
    source_field_input: str = ""
    constraints_input: str = ""
    is_demo: bool = False
    abstraction: Optional[Abstraction] = None
    papers: list[Paper] = Field(default_factory=list)
    evaluations: list[Evaluation] = Field(default_factory=list)
    candidate_ids: list[str] = Field(default_factory=list)  # up to 3 connections carried forward
    proposal: Optional[Proposal] = None
    insufficient_reason: str = ""  # set when the evidence did not support any connection
    agents: list[AgentStatus] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    error: str = ""
