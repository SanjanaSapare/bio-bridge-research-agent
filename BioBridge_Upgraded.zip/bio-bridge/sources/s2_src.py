"""Semantic Scholar Graph API search (API key optional)."""
from __future__ import annotations

import re
from typing import Callable, Optional
from urllib.parse import urlparse

import requests

from integrity import clean_arxiv_id, clean_doi
from schemas import Paper
from sources import SourceError

S2_URL = "https://api.semanticscholar.org/graph/v1/paper/search"
FIELDS = "paperId,title,abstract,year,url,authors,externalIds"


class RateLimited(SourceError):
    """Semantic Scholar answered 429."""


def _default_get(url: str, **kw):
    return requests.get(url, **kw)


def _safe_s2_url(url: str, pid: str) -> str:
    """Use the API-provided link only if it really points at semanticscholar.org."""
    host = (urlparse(url or "").hostname or "").lower()
    if (url or "").startswith("https://") and (host == "semanticscholar.org" or host.endswith(".semanticscholar.org")):
        return url
    return f"https://www.semanticscholar.org/paper/{pid}"


def parse_results(payload: dict, target_field: str = "") -> list[Paper]:
    papers: list[Paper] = []
    for item in (payload or {}).get("data") or []:
        title = (item.get("title") or "").strip()
        abstract = " ".join((item.get("abstract") or "").split())
        pid = item.get("paperId")
        if not (title and abstract and pid and re.fullmatch(r"[0-9a-fA-F]{6,64}", str(pid))):
            continue
        ext = item.get("externalIds") or {}
        arxiv_id = clean_arxiv_id(ext.get("ArXiv"))
        doi = clean_doi(ext.get("DOI"))
        year = item.get("year")
        authors = [a.get("name", "") for a in (item.get("authors") or []) if isinstance(a, dict)]
        papers.append(
            Paper(
                paper_id=f"arxiv:{arxiv_id}" if arxiv_id else f"s2:{pid}",
                title=title,
                abstract=abstract,
                authors=authors,
                year=year if isinstance(year, int) else None,
                source="Semantic Scholar",
                url=f"https://arxiv.org/abs/{arxiv_id}" if arxiv_id else _safe_s2_url(item.get("url"), pid),
                arxiv_id=arxiv_id,
                doi=doi,
                target_field=target_field,
            )
        )
    return papers


def search_s2(
    search_query: str,
    target_field: str,
    max_results: int,
    timeout: int,
    api_key: str = "",
    http_get: Optional[Callable] = None,
) -> list[Paper]:
    get = http_get or _default_get
    headers = {"User-Agent": "Bio-Bridge/1.0 (cross-disciplinary research tool)"}
    if api_key:
        headers["x-api-key"] = api_key
    params = {"query": search_query, "limit": max_results, "fields": FIELDS}
    try:
        resp = get(S2_URL, params=params, headers=headers, timeout=timeout)
    except Exception as exc:
        raise SourceError(f"Semantic Scholar request failed ({type(exc).__name__})") from exc
    if resp.status_code == 429:
        raise RateLimited("Semantic Scholar rate limit reached (429)")
    if resp.status_code != 200:
        raise SourceError(f"Semantic Scholar returned HTTP {resp.status_code}")
    try:
        payload = resp.json()
    except ValueError as exc:
        raise SourceError("Semantic Scholar returned unreadable data") from exc
    return parse_results(payload, target_field)
