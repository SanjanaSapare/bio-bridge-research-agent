"""Research retrieval clients (arXiv, Semantic Scholar)."""


class SourceError(RuntimeError):
    """A search source failed (network error, HTTP error, rate limit)."""
