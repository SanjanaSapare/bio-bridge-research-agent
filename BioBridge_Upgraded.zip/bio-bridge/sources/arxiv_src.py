"""arXiv search through the public Atom API (no key needed)."""
from __future__ import annotations

import re
from typing import Callable, Optional

import requests

from integrity import clean_arxiv_id
from schemas import Paper
from sources import SourceError

ARXIV_URL = "https://export.arxiv.org/api/query"
HEADERS = {"User-Agent": "Bio-Bridge/1.0 (cross-disciplinary research tool)"}


def _default_get(url: str, **kw):
    return requests.get(url, **kw)


def build_query(keywords: list[str], search_query: str) -> str:
    """OR over quoted keyword phrases; relevance sorting plus local re-ranking keeps results sane."""
    terms = [k.strip() for k in keywords if k and k.strip()][:4]
    if terms:
        return " OR ".join(f'all:"{t}"' for t in terms)
    words = re.findall(r"[A-Za-z0-9\-]+", search_query)[:6]
    return " OR ".join(f"all:{w}" for w in words)


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


_NS = {"a": "http://www.w3.org/2005/Atom", "x": "http://arxiv.org/schemas/atom"}


def _entries(text: str) -> list[dict]:
    """Atom entries as plain dicts (standard library only, so behaviour is identical everywhere)."""
    import xml.etree.ElementTree as ET

    try:
        root = ET.fromstring(text)
    except ET.ParseError as exc:
        raise SourceError("arXiv returned unreadable data") from exc
    out = []
    for e in root.findall("a:entry", _NS):
        out.append(
            {
                "id": e.findtext("a:id", "", _NS),
                "title": e.findtext("a:title", "", _NS),
                "summary": e.findtext("a:summary", "", _NS),
                "published": e.findtext("a:published", "", _NS),
                "authors": [n.text or "" for n in e.findall("a:author/a:name", _NS)],
                "doi": e.findtext("x:doi", "", _NS),
            }
        )
    return out


def parse_feed(text: str, target_field: str = "") -> list[Paper]:
    """Records come only from the feed. Identifiers are validated; malformed ones are left blank,
    never repaired or guessed. Entries without a valid arXiv id, title or abstract are skipped."""
    papers: list[Paper] = []
    for e in _entries(text):
        arxiv_id = clean_arxiv_id((e["id"] or "").split("/abs/")[-1].strip())
        title = _clean(e["title"])
        abstract = _clean(e["summary"])
        if not arxiv_id or not title or not abstract:
            continue
        year = None
        published = e["published"] or ""
        if re.match(r"\d{4}", published):
            year = int(published[:4])
        papers.append(
            Paper(
                paper_id=f"arxiv:{arxiv_id}",
                title=title,
                abstract=abstract,
                authors=[_clean(a) for a in e["authors"]],
                year=year,
                source="arXiv",
                url=f"https://arxiv.org/abs/{arxiv_id}",
                arxiv_id=arxiv_id,
                doi=e["doi"],
                target_field=target_field,
            )
        )
    return papers


def search_arxiv(
    keywords: list[str],
    search_query: str,
    target_field: str,
    max_results: int,
    timeout: int,
    http_get: Optional[Callable] = None,
) -> list[Paper]:
    get = http_get or _default_get
    params = {
        "search_query": build_query(keywords, search_query),
        "start": 0,
        "max_results": max_results,
        "sortBy": "relevance",
    }
    try:
        resp = get(ARXIV_URL, params=params, headers=HEADERS, timeout=timeout)
    except Exception as exc:
        raise SourceError(f"arXiv request failed ({type(exc).__name__})") from exc
    if resp.status_code != 200:
        raise SourceError(f"arXiv returned HTTP {resp.status_code}")
    return parse_feed(resp.text, target_field)
