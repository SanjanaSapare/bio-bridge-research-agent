=====================================================
  BIO-BRIDGE  -  QUICK START (Windows 10 / 11)
=====================================================

WHAT IT IS
  Describe a hard problem. Four AI agents (Abstractor, Explorer, Critic, Translator)
  look for real research papers in unrelated fields, test whether the idea truly
  transfers, and draft a research proposal.

-----------------------------------------------------
  THE 4 STEPS
-----------------------------------------------------

STEP 1 - Extract the ZIP
  Right-click bio_bridge_hackathon.zip  >  Extract All...
  Open the extracted "bio-bridge" folder. (Do not run files from inside the zip.)

STEP 2 - Install Python (one time, skip if you already have 3.10 or newer)
  Download Python 3.12 or 3.13 from https://www.python.org/downloads/
  On the FIRST installer screen tick  "Add python.exe to PATH"  then click Install Now.

STEP 3 - Get your FREE Gemini key (one time)
  a. Go to https://aistudio.google.com/apikey and sign in with a Google account.
  b. Click "Create API key" and copy it. Keep it private.
  c. Do NOT turn on billing if you want to stay free.

STEP 4 - Double-click   Start_BioBridge.bat
  - FIRST RUN (takes a few minutes): it creates a private Python environment, installs
    the packages, then creates a settings file called ".env" and opens it in Notepad.
    Replace   your_key_here   with your key (after GEMINI_API_KEY=), press Ctrl+S,
    and close Notepad.
  - Your browser opens at   http://localhost:8501
  - NEXT RUNS start in a few seconds (nothing is reinstalled).

  The settings file looks like this:
      GEMINI_API_KEY=paste-your-key-here
      MODEL=gemini-3.5-flash-lite
      S2_API_KEY=
  MODEL must be a Gemini model that is "free of charge" for you. Check the Free Tier
  column at https://ai.google.dev/gemini-api/docs/pricing (it can differ by account
  and change over time). S2_API_KEY is optional and can stay empty.

-----------------------------------------------------
  USING THE APP
-----------------------------------------------------
  Home / New Search : type a problem (or click an example) and press Start.
  Live progress     : watch the four agents work. A full run takes a few minutes.
  Results           : the best cross-field match, why it fits, and where it breaks.
  Proposal          : read, edit, and download as Markdown.
  My Projects       : completed runs are saved on your computer; open them again free.
  Research Library  : all papers found so far.
  Settings          : shows whether your key is set (it never shows the key itself).

  No key yet? Home and My Projects can open cached demonstrations if any are included
  in the data\examples folder. Those need no key and no internet.

-----------------------------------------------------
  HOW TO STOP IT SAFELY
-----------------------------------------------------
  Click into the black launcher window and press  Ctrl + C.
  If it asks "Terminate batch job (Y/N)?" type  Y  and press Enter.
  You can also just close the black window. Closing the browser tab alone does NOT
  stop the program.

-----------------------------------------------------
  TROUBLESHOOTING
-----------------------------------------------------
  "Python 3.10 or newer was not found"
     Install Python (Step 2) and tick "Add python.exe to PATH". If you already did,
     restart the computer once. The Microsoft Store "python" shortcut does not count.

  "Package installation failed"
     You need an internet connection and pypi.org must not be blocked (VPN, school or
     work proxy). If your Python is very new (3.14 or later), install Python 3.12 or
     3.13, delete the hidden-looking ".venv" folder inside bio-bridge, and run again.

  Window shows "Live mode is not configured yet"
     Open the file named .env (right-click > Open with > Notepad), fix GEMINI_API_KEY
     and MODEL, save, stop the app and start it again. Windows may hide the file
     extension; the file is called exactly  .env  (no .txt at the end).

  Error 429 / "rate limit" / "daily quota"
     The free tier has limits per minute AND per day, and they can change. For a minute
     limit, wait about a minute and try again. For a daily limit, use a saved project
     or a cached demonstration, or try again tomorrow. Limits are not unlimited.

  Error 404 "model not found"
     Change MODEL in .env to another free-tier model from the pricing page.

  Error 400 / 401 / 403 "API key"
     The key is wrong, inactive, or not available in your country. Create a new one.

  "Research retrieval failed"
     arXiv or Semantic Scholar could not be reached. Check your internet and retry.
     arXiv is polite-rate-limited, so the search step takes tens of seconds.

  Browser does not open / page does not load
     Open http://localhost:8501 yourself. If the launcher says the app is already
     running, it opens that existing copy instead of starting a second one. If something
     else is using port 8501, close it or restart the computer.

  First live run is slow
     It downloads a small language-embedding model once (about 100 to 150 MB). This is
     not a chatbot model; it only helps pick which papers to read, on your computer.

  Windows SmartScreen / firewall pop-up
     Choose "Run anyway" for the .bat file if you trust this download. The app only
     listens on your own computer (localhost).

-----------------------------------------------------
  GOOD TO KNOW
-----------------------------------------------------
  * Keep .env private. Never email it or upload it to GitHub.
  * Google may use free-tier content to improve its products. Do not enter
    confidential information.
  * The launcher also creates a small file at  %USERPROFILE%\.streamlit\credentials.toml
    so Streamlit does not ask for an email address on first start.
  * Results are research aids. They are not peer reviewed. The 0-10 transferability
    score is a ranking aid, not a probability of success.
  * Bio-Bridge reads paper ABSTRACTS only, never full papers. Quoted statements are
    checked to exist in the abstract; that does not prove the paper is correct.
  * If the research does not support a connection, the app says so on purpose.
  * More detail (deployment, tests, project layout): see README.md


EVIDENCE VERIFICATION
On the Results screen, click Verify Evidence to check retrieved records against live arXiv or Semantic Scholar metadata. Expand Detailed verification report for per-source results, or download the report as JSON. If an API is unavailable, the check is marked incomplete. This verifies record identity/metadata, not scientific truth. Claim excerpt checks only confirm that quoted words appear in the retrieved abstract; they do not prove that the claim is logically supported. Bio-Bridge only assesses abstracts unless full text is explicitly available.
