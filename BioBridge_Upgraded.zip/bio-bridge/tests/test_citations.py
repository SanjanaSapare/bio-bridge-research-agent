import unittest

from agents import critic, explorer
from agents.critic import build_evaluation, select_candidates
from integrity import clean_arxiv_id, clean_doi, scrub_text, verify_quote
from schemas import CriticOut, Paper
from sources import SourceError, arxiv_src, s2_src
from tests import fakes


def paper(pid="arxiv:2101.00001", **kw) -> Paper:
    base = dict(paper_id=pid, title="T", abstract=fakes.ABSTRACT, source="arXiv", url="https://arxiv.org/abs/2101.00001")
    base.update(kw)
    return Paper(**base)


def evaluation(pid, **kw):
    return build_evaluation(CriticOut.model_validate(fakes.critic_json(**kw)), paper(pid))


class IdentifierTests(unittest.TestCase):
    def test_doi_normalised_or_rejected(self):
        self.assertEqual(clean_doi("https://doi.org/10.1000/abc.1"), "10.1000/abc.1")
        self.assertEqual(clean_doi("doi: 10.1000/abc."), "10.1000/abc")
        self.assertEqual(clean_doi("not-a-doi"), "")
        self.assertEqual(clean_doi(None), "")

    def test_arxiv_id_normalised_or_rejected(self):
        self.assertEqual(clean_arxiv_id("arXiv:2101.00001v3"), "2101.00001")
        self.assertEqual(clean_arxiv_id("http://arxiv.org/abs/hep-th/9901001v2"), "hep-th/9901001")
        self.assertEqual(clean_arxiv_id("../etc/passwd"), "")

    def test_verify_quote(self):
        self.assertTrue(verify_quote("Agents deposit decaying markers", fakes.ABSTRACT))
        self.assertTrue(verify_quote("agents  DEPOSIT decaying-markers", fakes.ABSTRACT))  # spacing/case/hyphen
        self.assertTrue(verify_quote("We study decentralised routing ... reduces congestion in simulation", fakes.ABSTRACT))
        self.assertFalse(verify_quote("reduces congestion ... We study decentralised routing", fakes.ABSTRACT))  # order
        self.assertFalse(verify_quote("Results were 40 percent better than every baseline", fakes.ABSTRACT))
        self.assertFalse(verify_quote("short", "short text here"))  # too short to be evidence
        self.assertFalse(verify_quote("", fakes.ABSTRACT))

    def test_scrub_keeps_retrieved_and_removes_everything_else(self):
        dropped = []
        ids, dois, urls = {"arxiv:1.1"}, {"10.1000/real"}, {"https://arxiv.org/abs/1.1"}
        text = ("See [arxiv:1.1], arxiv:2.2, https://arxiv.org/abs/1.1 and https://evil.example/x; "
                "DOI 10.1000/real vs 10.9999/fake and s2:abc123.")
        out = scrub_text(text, ids, dois, urls, dropped)
        self.assertIn("[arxiv:1.1]", out)
        self.assertIn("https://arxiv.org/abs/1.1", out)
        self.assertIn("10.1000/real", out)
        for bad in ("arxiv:2.2", "https://evil.example/x", "10.9999/fake", "s2:abc123"):
            self.assertNotIn(bad, out)
            self.assertIn(bad, dropped)


class ParsingTests(unittest.TestCase):
    def test_arxiv_metadata(self):
        xml = fakes.atom([("2101.00001", "A   spaced\n title", "10.1000/xyz")])
        p = arxiv_src.parse_feed(xml, "Ecology")[0]
        self.assertEqual((p.paper_id, p.arxiv_id, p.doi), ("arxiv:2101.00001", "2101.00001", "10.1000/xyz"))
        self.assertEqual(p.title, "A spaced title")
        self.assertEqual(p.authors, ["Ada Lovelace", "Alan Turing"])
        self.assertEqual((p.year, p.url, p.source), (2020, "https://arxiv.org/abs/2101.00001", "arXiv"))

    def test_arxiv_missing_metadata_stays_empty_not_guessed(self):
        p = arxiv_src.parse_feed(fakes.atom([("2101.00002", "No doi")]))[0]
        self.assertEqual(p.doi, "")

    def test_arxiv_bad_records_skipped_and_garbage_raises(self):
        xml = fakes.atom([("not-an-id", "Bad id"), ("2101.00003", "Good")])
        self.assertEqual([p.paper_id for p in arxiv_src.parse_feed(xml)], ["arxiv:2101.00003"])
        with self.assertRaises(SourceError):
            arxiv_src.parse_feed("<html>rate limited")

    def test_s2_metadata_and_url_validation(self):
        h = "a" * 40
        ok = {"paperId": h, "title": "T", "abstract": "An abstract that is long enough to count.", "year": 2021,
              "url": f"https://www.semanticscholar.org/paper/{h}", "authors": [{"name": "G Hopper"}, {"name": "G Hopper"}],
              "externalIds": {"DOI": "10.5555/abc", "ArXiv": "2101.00005"}}
        evil = dict(ok, paperId="b" * 40, url="https://phish.example/paper", externalIds={"DOI": "garbage"})
        nohex = dict(ok, paperId="zzzz-not-hex")
        noabs = dict(ok, paperId="c" * 40, abstract=None)
        ps = s2_src.parse_results({"data": [ok, evil, nohex, noabs]}, "Physics")
        self.assertEqual(len(ps), 2)
        a, b = ps
        self.assertEqual((a.paper_id, a.arxiv_id, a.doi, a.url), ("arxiv:2101.00005", "2101.00005", "10.5555/abc", "https://arxiv.org/abs/2101.00005"))
        self.assertEqual(a.authors, ["G Hopper"])  # de-duplicated
        self.assertEqual(b.url, f"https://www.semanticscholar.org/paper/{'b' * 40}")  # off-site link replaced
        self.assertEqual(b.doi, "")  # malformed DOI dropped, not repaired
        self.assertEqual(b.paper_id, f"s2:{'b' * 40}")

    def test_duplicate_records_are_merged_without_overwriting(self):
        keep = paper(authors=[], doi="", year=None)
        other = paper(authors=["X Y"], doi="10.1000/zz", year=2019)
        explorer._merge_missing(keep, other)
        self.assertEqual((keep.authors, keep.doi, keep.year), (["X Y"], "10.1000/zz", 2019))
        keep2 = paper(authors=["A"], doi="10.1000/aa", year=2020)
        explorer._merge_missing(keep2, other)
        self.assertEqual((keep2.authors, keep2.doi, keep2.year), (["A"], "10.1000/aa", 2020))


class CriticVerificationTests(unittest.TestCase):
    def test_verified_claims_are_kept(self):
        ev = evaluation("arxiv:1.1")
        self.assertEqual(len(ev.reported_findings), 1)
        self.assertIsNotNone(ev.paper_objective)
        self.assertTrue(ev.score_reliable)
        self.assertIn("3 of 3", ev.verification_note)

    def test_fabricated_quote_is_dropped_and_evidence_capped(self):
        ev = evaluation("arxiv:1.1", bad_quote=True, evid=9, label="promising", mech=9, obj=9, cons=9, adapt=9)
        self.assertEqual(ev.reported_findings, [])
        self.assertEqual(ev.scores.evidence_strength, 3.0)
        self.assertNotEqual(ev.label, "promising")
        self.assertIn("removed", ev.verification_note)
        self.assertTrue(any("Evidence strength lowered" in n for n in ev.score_notes))

    def test_abstract_only_caps_evidence_even_with_verified_findings(self):
        ev = evaluation("arxiv:1.1", evid=10)
        self.assertEqual(ev.scores.evidence_strength, 7.0)

    def test_nothing_verifiable_marks_score_unreliable(self):
        d = fakes.critic_json(bad_quote=True)
        d.update(paper_objective=None, reported_limitations=[])
        ev = build_evaluation(CriticOut.model_validate(d), paper("arxiv:1.1"))
        self.assertFalse(ev.score_reliable)

    def test_score_does_not_depend_on_similarity(self):
        a, b = paper("arxiv:1.1", similarity_raw=0.95, similarity_norm=1.0), paper("arxiv:1.2", similarity_raw=0.1, similarity_norm=0.0)
        out = CriticOut.model_validate(fakes.critic_json())
        self.assertEqual(build_evaluation(out, a).transferability_score, build_evaluation(out, b).transferability_score)

    def test_select_candidates_up_to_three_never_padded(self):
        evs = [evaluation(f"arxiv:{i}.1", mech=m, obj=m, cons=m, evid=m, adapt=m, label="speculative")
               for i, m in enumerate([9, 8, 7, 6, 1, 1], 1)]
        cands = select_candidates(evs)
        self.assertEqual(len(cands), 3)
        self.assertEqual([c.paper_id for c in cands], ["arxiv:1.1", "arxiv:2.1", "arxiv:3.1"])
        self.assertEqual(select_candidates(evs[4:]), [])  # only poorly supported -> nothing carried forward
        self.assertEqual(len(select_candidates(evs[:1])), 1)

    def test_speculative_low_score_is_still_a_candidate(self):
        ev = evaluation("arxiv:1.1", mech=4, obj=4, cons=4, evid=4, adapt=4, label="speculative")
        self.assertEqual((ev.label, ev.transferability_score), ("speculative", 4.0))
        self.assertEqual(len(select_candidates([ev])), 1)


if __name__ == "__main__":
    unittest.main()
