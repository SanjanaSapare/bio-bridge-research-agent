import unittest
from schemas import Paper
from source_verification import verify_sources

class Response:
    status_code = 200
    text = '''<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom"><entry><id>http://arxiv.org/abs/2101.00001</id><title>A Test Paper</title><summary>Some abstract text.</summary></entry></feed>'''
    def json(self): return {}

def fake_get(url, **kwargs):
    return Response()

class VerificationTests(unittest.TestCase):
    def test_arxiv_identifier_and_title_checked_against_record(self):
        p = Paper(paper_id="arxiv:2101.00001", title="A Test Paper", abstract="An abstract long enough to be stored.", source="arXiv", url="https://arxiv.org/abs/2101.00001", arxiv_id="2101.00001")
        report = verify_sources([p], [], http_get=fake_get)
        self.assertEqual(report["summary"]["sources_checked"], 1)
        self.assertEqual(report["summary"]["source_records_matched"], 1)
        self.assertIn("matched", [x["status"] for x in report["sources"][0]["checks"]])

    def test_lookup_failure_is_incomplete_not_verified(self):
        p = Paper(paper_id="arxiv:2101.00001", title="A Test Paper", abstract="An abstract long enough to be stored.", source="arXiv", url="https://arxiv.org/abs/2101.00001", arxiv_id="2101.00001")
        def fail(*args, **kwargs): raise TimeoutError()
        report = verify_sources([p], [], http_get=fail)
        self.assertEqual(report["sources"][0]["status"], "incomplete")
        self.assertEqual(report["summary"]["source_records_matched"], 0)

if __name__ == '__main__': unittest.main()
