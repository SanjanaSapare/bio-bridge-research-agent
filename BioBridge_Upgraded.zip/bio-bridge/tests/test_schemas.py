import unittest

from pydantic import ValidationError

from llm import extract_json
from schemas import Abstraction, AbstractionOut, CriticOut, Evaluation
from scoring import (EVIDENCE_CAP_ABSTRACT_ONLY, EVIDENCE_CAP_NO_VERIFIED_FINDING, apply_evidence_caps,
                     guard_label, normalize_similarity, weighted_score)
from tests import fakes

S = dict(objective_alignment=8, mechanism_alignment=8, constraint_compatibility=8,
         evidence_strength=8, adaptation_feasibility=8)


class SchemaTests(unittest.TestCase):
    def test_valid_abstraction_any_number_of_directions_3_to_6(self):
        for n in (3, 4):
            Abstraction.model_validate(fakes.abstraction_json(n))
        d = fakes.abstraction_json(4)
        d["bridge_queries"] = d["bridge_queries"][:2]
        with self.assertRaises(ValidationError):
            Abstraction.model_validate(d)

    def test_duplicate_search_queries_rejected(self):
        d = fakes.abstraction_json(3)
        d["bridge_queries"][1]["search_query"] = d["bridge_queries"][0]["search_query"]
        with self.assertRaises(ValidationError):
            Abstraction.model_validate(d)

    def test_model_output_must_include_decomposition_fields(self):
        d = fakes.abstraction_json()
        del d["mechanisms"]
        with self.assertRaises(ValidationError):
            AbstractionOut.model_validate(d)

    def test_source_field_not_required(self):
        d = fakes.abstraction_json()
        del d["source_field"]
        self.assertEqual(AbstractionOut.model_validate(d).source_field, "unspecified")

    def test_critic_needs_a_counterpoint(self):
        d = fakes.critic_json()
        d["differences"], d["risks"] = [], []
        with self.assertRaises(ValidationError):
            CriticOut.model_validate(d)

    def test_label_aliases_and_score_clamping(self):
        d = fakes.critic_json(label="Promising with modification", mech=14)
        out = CriticOut.model_validate(d)
        self.assertEqual(out.label, "promising_with_modifications")
        self.assertEqual(out.scores.mechanism_alignment, 10.0)

    def test_extract_json_handles_fences_and_noise(self):
        self.assertEqual(extract_json('```json\n{"a": 1}\n```'), {"a": 1})
        self.assertEqual(extract_json('Sure! {"a": 2} done'), {"a": 2})
        with self.assertRaises(ValueError):
            extract_json("no json here")

    def test_legacy_saved_evaluation_still_loads(self):
        old = {"paper_id": "arxiv:1.1", "structural_score": 6, "shared_structure": "Local coordination.",
               "mappings": [], "why_it_might_work": ["x"], "assumptions": [], "limitations": ["a", "b"],
               "evidence_strength": "weak", "recommendation": "promising", "similarity_norm": 0.9,
               "heuristic_confidence": 0.8}
        ev = Evaluation.model_validate(old)
        self.assertTrue(ev.legacy)
        self.assertFalse(ev.score_reliable)


class ScoringTests(unittest.TestCase):
    def test_weighted_score_and_rounding(self):
        self.assertEqual(weighted_score(S), 8.0)
        self.assertEqual(weighted_score({k: 0 for k in S}), 0.0)
        s = dict(S, mechanism_alignment=7, objective_alignment=7)  # 7.7 -> nearest 0.5
        self.assertEqual(weighted_score(s), 7.5)

    def test_similarity_is_not_an_input_to_the_score(self):
        import inspect
        self.assertEqual(list(inspect.signature(weighted_score).parameters), ["scores"])
        self.assertEqual(normalize_similarity(0.2), 0.0)
        self.assertEqual(normalize_similarity(0.9), 1.0)

    def test_evidence_caps(self):
        s, notes = apply_evidence_caps(dict(S, evidence_strength=10), verified_findings=2)
        self.assertEqual(s["evidence_strength"], EVIDENCE_CAP_ABSTRACT_ONLY)
        self.assertTrue(notes)
        s, notes = apply_evidence_caps(dict(S, evidence_strength=9), verified_findings=0)
        self.assertEqual(s["evidence_strength"], EVIDENCE_CAP_NO_VERIFIED_FINDING)
        s, notes = apply_evidence_caps(dict(S, evidence_strength=2), verified_findings=0)
        self.assertEqual((s["evidence_strength"], notes), (2, []))

    def test_label_guard_only_lowers(self):
        self.assertEqual(guard_label("promising", 2.5, S, 3)[0], "poorly_supported")
        self.assertEqual(guard_label("promising", 4.5, S, 3)[0], "speculative")
        self.assertEqual(guard_label("promising", 6.5, S, 3)[0], "promising_with_modifications")
        self.assertEqual(guard_label("promising", 8.0, S, 3)[0], "promising")
        self.assertEqual(guard_label("speculative", 9.0, S, 3)[0], "speculative")  # never raised
        self.assertEqual(guard_label("poorly_supported", 9.0, S, 3)[0], "poorly_supported")

    def test_nothing_verified_caps_label_at_speculative(self):
        lab, notes = guard_label("promising", 9.0, S, verified_total=0)
        self.assertEqual(lab, "speculative")
        self.assertTrue(notes)


if __name__ == "__main__":
    unittest.main()
