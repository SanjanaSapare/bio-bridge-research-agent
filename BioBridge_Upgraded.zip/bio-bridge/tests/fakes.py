"""Test doubles: a scripted Gemini client, a fake HTTP layer and a fake embedder. No network needed."""
from __future__ import annotations

import json

from config import Settings

# What every fake paper's abstract says. Critic quotes below are copied from it word for word.
ABSTRACT = (
    "We study decentralised routing of many agents in constrained spaces. Agents deposit decaying markers "
    "that guide later agents, which reduces congestion in simulation. Results show shorter paths than "
    "shortest-path baselines, but the markers assume reliable local sensing."
)
Q_OBJECTIVE = "decentralised routing of many agents in constrained spaces"
Q_FINDING = "Results show shorter paths than shortest-path baselines"
Q_LIMIT = "the markers assume reliable local sensing"

FIELDS = ["Ecology", "Statistical physics", "Immunology", "Economics"]


def settings(**kw) -> Settings:
    base = dict(gemini_api_key="test-key", model="test-model", s2_api_key="",
                max_papers_per_search=3, rerank_limit=8, shortlist_limit=3)
    base.update(kw)
    return Settings(**base)


def abstraction_json(n=4) -> dict:
    return {
        "source_field": "Robotics",
        "objective": "Route many drones through tight spaces without collisions.",
        "abstract_description": "Many simple agents must reach goals using only local information.",
        "math_primitives": ["decentralised consensus", "graph diffusion"],
        "mechanisms": ["local signalling with decay"],
        "variables": ["path length", "collision rate"],
        "constraints": ["no central controller", "low compute per agent"],
        "bridge_queries": [
            {"target_field": f, "keywords": [f.lower(), "collective"], "search_query": f"{f.lower()} collective routing",
             "rationale": f"{f} studies collective behaviour of simple units.",
             "mechanism_targeted": "local signalling with decay"}
            for f in FIELDS[:n]
        ],
    }


def claim(statement, quote):
    return {"statement": statement, "quote": quote}


def critic_json(mech=7.5, obj=7.5, cons=7.0, evid=6.0, adapt=6.5, label="promising_with_modifications",
                bad_quote=False, extra_claims=None) -> dict:
    d = {
        "paper_objective": claim("Decentralised routing of many agents", Q_OBJECTIVE),
        "paper_method": None,
        "reported_findings": [claim("Shorter paths than shortest-path baselines in simulation",
                                    "Results were 40 percent better than every baseline" if bad_quote else Q_FINDING)],
        "reported_limitations": [claim("Assumes reliable local sensing", Q_LIMIT)],
        "mechanism_extracted": "Decaying markers left by earlier agents guide later agents.",
        "shared_structure": "Both systems coordinate through local interaction only.",
        "mappings": [{"problem_concept": "drone", "paper_concept": "agent", "note": ""}],
        "what_transfers": ["Marker-guided routing rule"],
        "needs_modification": ["Replace physical markers with broadcast messages"],
        "differences": ["The paper's setting is a simulation, not hardware."],
        "assumptions": ["Signals can be abstracted as local messages."],
        "risks": [{"risk": "Local sensing may be unreliable indoors.", "mitigation": "Add sensor-noise tests."}],
        "scores": {"objective_alignment": obj, "mechanism_alignment": mech, "constraint_compatibility": cons,
                   "evidence_strength": evid, "adaptation_feasibility": adapt},
        "score_rationale": "Mechanism fits; evidence is simulation only.",
        "main_uncertainty": "Whether decaying markers survive real sensing noise.",
        "label": label,
    }
    if extra_claims:
        d["reported_findings"] += extra_claims
    return d


def proposal_json(cited, prose_extra="") -> dict:
    return {
        "title": "Test proposal",
        "executive_summary": "Summary citing [arxiv:0000.0000] which is invented. " + prose_extra,
        "problem_and_structure": "Structure.",
        "selected_mechanism": "Mechanism.",
        "hypothesis": "Hypothesis H1.",
        "methodology": ["Step one", "Step two"],
        "variables_and_updates": "Variables.",
        "experiments": [{"name": "E1", "description": "d", "baselines": ["b"], "metrics": ["m"]}],
        "expected_outcomes": ["Outcome"],
        "risks": ["Risk"],
        "limitations_and_assumptions": ["Limit"],
        "cited_paper_ids": cited,
        "adaptation": {"reuse": ["Marker rule"], "modify": ["Use messages"], "how_it_addresses_problem": "Reduces congestion."},
        "validation_plan": {"baseline": "Shortest-path routing", "metrics": ["collision rate"],
                            "required_data": ["indoor map"], "failure_conditions": ["No gain over baseline"]},
        "evidence_statement": "Simulation evidence only; hardware transfer is untested.",
    }


class _Resp:
    def __init__(self, text):
        self.text = text


class FakeClient:
    """Mimics client.models.generate_content; picks a reply from the schema named in the system prompt."""

    def __init__(self, critic_kwargs=None, cited=None, fail_with=None, critic_fail_after=None,
                 critic_garbage_on=None, prose_extra="", abstraction_n=4):
        self.models = self
        self.calls = []
        self.critic_kwargs = critic_kwargs or {}
        self.cited = cited
        self.fail_with = fail_with
        self.critic_fail_after = critic_fail_after   # raise fail_with from the Nth critic call on
        self.critic_garbage_on = critic_garbage_on or set()  # critic call numbers that return junk
        self.prose_extra = prose_extra
        self.abstraction_n = abstraction_n
        self._critic_n = 0

    def generate_content(self, model, contents, config):
        sysmsg = config["system_instruction"]
        if '"title": "CriticOut"' in sysmsg:
            kind = "critic"
        elif '"title": "ProposalOut"' in sysmsg:
            kind = "proposal"
        elif '"title": "AbstractionOut"' in sysmsg:
            kind = "abstraction"
        else:
            raise AssertionError("unexpected schema in system prompt")
        self.calls.append(kind)
        if kind == "critic":
            self._critic_n += 1
            if self.critic_fail_after is not None and self._critic_n > self.critic_fail_after:
                raise self.fail_with
            if self._critic_n in self.critic_garbage_on:
                return _Resp("I think this paper is interesting.")
        elif self.fail_with is not None and self.critic_fail_after is None:
            raise self.fail_with
        if kind == "abstraction":
            return _Resp(json.dumps(abstraction_json(self.abstraction_n)))
        if kind == "critic":
            return _Resp(json.dumps(critic_json(**self.critic_kwargs)))
        ids = self.cited
        if ids is None:
            ids = [ln.split('id="')[1].split('"')[0] for ln in contents.splitlines() if ln.startswith("<paper id=")][:1]
        return _Resp(json.dumps(proposal_json(ids + ["arxiv:9999.9999"], self.prose_extra)))


class _HTTPResp:
    def __init__(self, status=200, text="", payload=None):
        self.status_code, self.text, self._payload = status, text, payload

    def json(self):
        return self._payload


def atom(entries) -> str:
    """entries: (arxiv_id, title) or (arxiv_id, title, doi)."""
    body = ""
    for e in entries:
        i, t = e[0], e[1]
        doi = f"<arxiv:doi>{e[2]}</arxiv:doi>" if len(e) > 2 else ""
        body += (f"<entry><id>http://arxiv.org/abs/{i}v1</id><published>2020-05-01T00:00:00Z</published>"
                 f"<title>  {t}\n </title><summary>  {ABSTRACT}\n</summary>"
                 f"<author><name>Ada Lovelace</name></author><author><name>Alan  Turing</name></author>{doi}</entry>")
    return ('<?xml version="1.0"?><feed xmlns="http://www.w3.org/2005/Atom" '
            f'xmlns:arxiv="http://arxiv.org/schemas/atom">{body}</feed>')


def make_http_get(s2_status=200, arxiv_status=200):
    """Each arXiv query returns 2 unique papers; Semantic Scholar returns 1 (or an error status)."""
    state = {"n": 0}

    def http_get(url, params=None, headers=None, timeout=None):
        state["n"] += 1
        n = state["n"]
        if "arxiv" in url:
            if arxiv_status != 200:
                return _HTTPResp(arxiv_status)
            q = params["search_query"]
            return _HTTPResp(200, atom([(f"2001.{n:04d}1", f"Paper A {q[:12]} {n}"),
                                        (f"2001.{n:04d}2", f"Paper B {q[:12]} {n}", f"10.1000/test.{n}")]))
        if s2_status != 200:
            return _HTTPResp(s2_status)
        return _HTTPResp(200, payload={"data": [{
            "paperId": f"{n:040x}", "title": f"S2 paper {n}", "abstract": ABSTRACT, "year": 2019,
            "url": f"https://www.semanticscholar.org/paper/{n:040x}", "externalIds": {"DOI": f"10.5555/s2.{n}"},
            "authors": [{"name": "Grace Hopper"}]}]})

    return http_get


def fake_embed(texts):
    """Deterministic vectors: query first, then papers with decreasing similarity to it."""
    out = [[1.0, 0.0, 0.0]]
    for i in range(len(texts) - 1):
        t = min(0.9, 0.1 + 0.07 * i)
        out.append([1.0 - t, t, 0.0])
    return out
