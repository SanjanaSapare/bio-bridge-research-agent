"""End-to-end pipeline tests with test doubles (no API keys, no internet)."""
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import cache
from agents import explorer, translator
from pipeline import run_pipeline
from schemas import RunResult
from tests import fakes


class E429(Exception):
    code = 429


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        tmp = Path(self.tmp.name)
        orig_save, orig_load = cache.save_run, cache.load_run  # default dir is bound at import time
        for m in (mock.patch.object(explorer, "ARXIV_DELAY", 0.0), mock.patch.object(explorer, "S2_DELAY", 0.0),
                  mock.patch.object(cache, "save_run", lambda res, key: orig_save(res, key, tmp)),
                  mock.patch.object(cache, "load_run", lambda key: orig_load(key, tmp))):
            m.start()
            self.addCleanup(m.stop)

    def run_it(self, client=None, http_get=None, embed=fakes.fake_embed, use_cache=False, st=None):
        events = []
        res = run_pipeline("A long enough problem statement for tests.", "Robotics", "", st or fakes.settings(),
                           on_status=lambda i, s, m: events.append((i, s)),
                           client=client or fakes.FakeClient(), embed=embed,
                           http_get=http_get or fakes.make_http_get(), use_cache=use_cache)
        return res, events

    # ------------------------------------------------------------ happy path
    def test_full_run_completes_all_four_agents(self):
        client = fakes.FakeClient()
        res, events = self.run_it(client=client)
        self.assertEqual(res.error, "")
        self.assertEqual([a.state for a in res.agents], ["completed"] * 4)
        self.assertEqual(client.calls[0], "abstraction")
        self.assertEqual(client.calls.count("critic"), 3)
        self.assertEqual(client.calls[-1], "proposal")
        self.assertIn((2, "running"), events)
        self.assertEqual(res.abstraction.objective[:5], "Route")
        self.assertTrue(1 <= len(res.candidate_ids) <= 3)
        self.assertTrue(set(res.candidate_ids) <= {p.paper_id for p in res.papers})
        self.assertIsNotNone(res.proposal)
        self.assertEqual(res.insufficient_reason, "")
        self.assertTrue(res.proposal.validation_plan.failure_conditions)

    def test_paper_metadata_survives_the_pipeline(self):
        res, _ = self.run_it()
        self.assertTrue(all(p.authors for p in res.papers))
        self.assertTrue(any(p.doi for p in res.papers))
        self.assertTrue(all(p.text_basis == "abstract" for p in res.papers))
        ref = res.proposal.references[0]
        src = next(p for p in res.papers if p.paper_id == ref.paper_id)
        self.assertEqual((ref.title, ref.url, ref.authors, ref.doi), (src.title, src.url, src.authors, src.doi))
        self.assertIn("abstracts only", res.proposal.evidence_basis)

    def test_retrieval_similarity_does_not_change_critic_input_or_score(self):
        res, _ = self.run_it()
        self.assertTrue(all(p.similarity_raw is not None for p in res.papers))
        scores = {e.transferability_score for e in res.evaluations}
        self.assertEqual(len(scores), 1)  # identical fake judgement -> identical score whatever the similarity

    # ------------------------------------------------------------ citation integrity
    def test_invented_citations_links_and_dois_are_removed(self):
        client = fakes.FakeClient(prose_extra="See https://made-up.example/p and 10.9999/invented and [s2:deadbeef].")
        res, _ = self.run_it(client=client)
        pr = res.proposal
        for bad in ("arxiv:0000.0000", "arxiv:9999.9999", "https://made-up.example/p", "10.9999/invented", "s2:deadbeef"):
            self.assertIn(bad, pr.dropped_citations)
            self.assertNotIn(bad, pr.executive_summary)
        retrieved = {p.paper_id for p in res.papers}
        self.assertTrue(all(r.paper_id in retrieved for r in pr.references))
        self.assertTrue(any("removed from the proposal" in w for w in res.warnings))

    def test_markdown_export_lists_only_retrieved_references(self):
        res, _ = self.run_it()
        md = translator.proposal_to_markdown(res.proposal, res.problem, res.abstraction)
        self.assertIn("## Validation plan", md)
        self.assertIn("abstracts only", md.lower())
        self.assertNotIn("9999.9999", md)
        self.assertIn(res.proposal.references[0].url, md)

    # ------------------------------------------------------------ cache
    def test_cache_roundtrip(self):
        self.run_it(use_cache=True)
        client = fakes.FakeClient()
        res2, _ = self.run_it(client=client, use_cache=True)
        self.assertEqual(client.calls, [])  # served from cache, zero LLM calls
        self.assertTrue(any("cache" in w.lower() for w in res2.warnings))
        tmp = Path(self.tmp.name)
        runs = cache.list_runs(tmp)
        self.assertEqual(len(runs), 1)
        self.assertTrue(cache.delete_run(runs[0]["key"], tmp))
        self.assertEqual(cache.list_runs(tmp), [])
        self.assertFalse(cache.delete_run("../evil", tmp))

    def test_saved_result_json_roundtrip(self):
        res, _ = self.run_it()
        again = RunResult.model_validate_json(res.model_dump_json())
        self.assertEqual(again.candidate_ids, res.candidate_ids)
        self.assertEqual(again.evaluations[0].reported_findings[0].quote, res.evaluations[0].reported_findings[0].quote)

    # ------------------------------------------------------------ insufficient / weak evidence
    def test_all_poorly_supported_says_so_instead_of_inventing_a_match(self):
        client = fakes.FakeClient(critic_kwargs=dict(mech=1, obj=1, cons=1, evid=1, adapt=1, label="poorly_supported"))
        res, _ = self.run_it(client=client)
        self.assertEqual(res.error, "")
        self.assertIsNone(res.proposal)
        self.assertEqual(res.candidate_ids, [])
        self.assertIn("did not support", res.insufficient_reason)
        self.assertNotIn("proposal", client.calls)  # no wasted API call
        self.assertEqual(len(res.evaluations), 3)
        self.assertEqual(res.agents[3].state, "completed")

    def test_low_score_speculative_does_not_stop_the_workflow(self):
        client = fakes.FakeClient(critic_kwargs=dict(mech=4, obj=4, cons=4, evid=4, adapt=4, label="speculative"))
        res, _ = self.run_it(client=client)
        self.assertIsNotNone(res.proposal)
        self.assertEqual({e.label for e in res.evaluations}, {"speculative"})

    def test_overclaimed_label_is_lowered_in_python(self):
        client = fakes.FakeClient(critic_kwargs=dict(mech=5, obj=5, cons=5, evid=5, adapt=5, label="promising"))
        res, _ = self.run_it(client=client)
        self.assertTrue(all(e.label != "promising" for e in res.evaluations))
        self.assertTrue(all(e.score_notes for e in res.evaluations))

    def test_fabricated_quotes_reduce_trust(self):
        client = fakes.FakeClient(critic_kwargs=dict(bad_quote=True, evid=10, label="promising", mech=10, obj=10, cons=10, adapt=10))
        res, _ = self.run_it(client=client)
        for e in res.evaluations:
            self.assertEqual(e.reported_findings, [])
            self.assertEqual(e.scores.evidence_strength, 3.0)
            self.assertNotEqual(e.label, "promising")

    # ------------------------------------------------------------ failures keep what finished
    def test_rate_limit_is_reported_not_raised(self):
        res, _ = self.run_it(client=fakes.FakeClient(fail_with=E429("rate limit per minute")),
                             st=fakes.settings(llm_max_retries=1))
        self.assertIn("rate limit", res.error.lower())
        self.assertEqual(res.agents[0].state, "failed")
        self.assertIsNone(res.proposal)

    def test_daily_quota_message(self):
        res, _ = self.run_it(client=fakes.FakeClient(fail_with=E429("quota exceeded: GenerateRequestsPerDay")))
        self.assertIn("DAILY quota", res.error)

    def test_critic_quota_midway_keeps_partial_evaluations_and_still_writes_proposal(self):
        client = fakes.FakeClient(fail_with=E429("rate limit per minute"), critic_fail_after=1)
        res, _ = self.run_it(client=client, st=fakes.settings(llm_max_retries=1))
        self.assertEqual(len(res.evaluations), 1)
        self.assertTrue(any("Stopped after 1 of 3" in w for w in res.warnings))
        self.assertIsNotNone(res.proposal)

    def test_one_malformed_critic_reply_skips_only_that_paper(self):
        res, _ = self.run_it(client=fakes.FakeClient(critic_garbage_on={2}), st=fakes.settings(llm_max_retries=1))
        self.assertEqual(len(res.evaluations), 2)
        self.assertTrue(any("Skipped" in w for w in res.warnings))
        self.assertEqual(res.error, "")

    def test_every_critic_reply_malformed_is_an_error_not_a_fake_result(self):
        res, _ = self.run_it(client=fakes.FakeClient(critic_garbage_on={1, 2, 3, 4, 5, 6}), st=fakes.settings(llm_max_retries=1))
        self.assertIn("invalid structured output", res.error)
        self.assertEqual(res.agents[2].state, "failed")
        self.assertEqual(res.evaluations, [])
        self.assertIsNone(res.proposal)
        self.assertTrue(res.papers)  # the Explorer's real papers are kept

    def test_translator_failure_keeps_everything_before_it(self):
        class Boom(fakes.FakeClient):
            def generate_content(self, model, contents, config):
                if '"title": "ProposalOut"' in config["system_instruction"]:
                    raise E429("rate limit per minute")
                return super().generate_content(model, contents, config)

        res, _ = self.run_it(client=Boom(), st=fakes.settings(llm_max_retries=1))
        self.assertIn("rate limit", res.error.lower())
        self.assertEqual([a.state for a in res.agents], ["completed", "completed", "completed", "failed"])
        self.assertTrue(res.evaluations and res.candidate_ids and res.papers)
        self.assertIsNone(res.proposal)

    # ------------------------------------------------------------ research sources
    def test_semantic_scholar_429_falls_back_to_arxiv(self):
        res, _ = self.run_it(http_get=fakes.make_http_get(s2_status=429))
        self.assertEqual(res.error, "")
        self.assertTrue(any("Semantic Scholar" in w for w in res.warnings))
        self.assertTrue(all(p.source == "arXiv" for p in res.papers))

    def test_all_sources_down_gives_clear_error_and_no_fake_papers(self):
        res, _ = self.run_it(http_get=fakes.make_http_get(s2_status=500, arxiv_status=503))
        self.assertIn("Could not retrieve research papers", res.error)
        self.assertEqual(res.papers, [])
        self.assertEqual(res.agents[1].state, "failed")
        self.assertIsNotNone(res.abstraction)  # the Abstractor's work is kept

    def test_empty_search_results_is_a_clear_error(self):
        def empty(url, params=None, headers=None, timeout=None):
            r = fakes._HTTPResp(200, text=fakes.atom([]), payload={"data": []})
            return r
        res, _ = self.run_it(http_get=empty)
        self.assertIn("Could not retrieve research papers", res.error)
        self.assertEqual((res.papers, res.evaluations, res.proposal), ([], [], None))

    def test_embedding_failure_degrades_gracefully(self):
        def boom(_):
            raise RuntimeError("model download blocked")
        res, _ = self.run_it(embed=boom)
        self.assertEqual(res.error, "")
        self.assertTrue(any("could not be computed" in w for w in res.warnings))
        self.assertTrue(all(p.similarity_raw is None for p in res.papers))
        self.assertIsNotNone(res.proposal)  # the Critic's judgement does not depend on embeddings


if __name__ == "__main__":
    unittest.main()
