"""Bio-Bridge: Cross-Disciplinary Research Matchmaker (Streamlit UI).

Layout follows the product wireframe: a dark sidebar (Home, New Search, My Projects,
Research Library, Settings) and these screens: dashboard, live agent progress,
cross-domain insight results, research proposal, project library, mobile-friendly stacking.
"""
from __future__ import annotations

import html
from datetime import datetime

import streamlit as st

import cache
from agents.critic import select_candidates
from agents.translator import proposal_to_markdown, reference_line
from config import ConfigError, load_settings
from pipeline import AGENT_NAMES, run_pipeline
from schemas import LABEL_TEXT, RunResult
from scoring import CRITERIA_TEXT, EXPLANATION, WEIGHTS
from source_verification import verify_sources

st.set_page_config(page_title="Bio-Bridge", page_icon="🧬", layout="wide", initial_sidebar_state="expanded")

EXAMPLE_PROBLEMS = {
    "Drone routing": dict(
        problem="We need better routing for autonomous drones in tight indoor spaces.",
        source="Robotics",
        constraints="Low compute per drone; no central controller; safety critical.",
    ),
    "Traffic signals": dict(
        problem="How can we coordinate traffic signals across a city grid so that cars face fewer "
        "stops and delays, using only communication between neighbouring intersections?",
        source="Transportation engineering",
        constraints="Neighbour-only communication; safety clearance times must be respected.",
    ),
    "Battery degradation": dict(
        problem="Can we get early warning that a lithium-ion battery is about to enter a phase of "
        "rapid capacity loss, using only routine charge/discharge measurements?",
        source="Battery engineering",
        constraints="Noisy data; limited history per cell; very few false alarms tolerated.",
    ),
    "Cancer drug delivery": dict(
        problem="How can drug-carrying nanoparticles find and accumulate in a tumour rather than in "
        "healthy tissue when they can only sense local chemical gradients and cannot be steered from outside?",
        source="Biomedical engineering",
        constraints="Local sensing only; biocompatible; dose must stay below toxic limits.",
    ),
    "Renewable energy storage": dict(
        problem="How should a grid with many small solar and wind sources and batteries decide when to "
        "store or release energy, using only local measurements, so supply and demand stay balanced?",
        source="Energy systems",
        constraints="No central dispatcher; unpredictable generation; battery wear costs.",
    ),
    "Soil regeneration": dict(
        problem="How can degraded farmland recover its soil structure and fertility with minimal external "
        "inputs, when many interacting processes have to reinforce each other over several seasons?",
        source="Agriculture",
        constraints="Low cost; multi-season timescale; variable weather.",
    ),
}

AGENT_BLURBS = [
    "Breaks the problem into objective, constraints, variables and mechanisms, and plans the searches.",
    "Retrieves real papers from arXiv and Semantic Scholar and keeps their source metadata.",
    "Tests whether each paper's mechanism really transfers, and where it breaks.",
    "Turns supported connections into a testable proposal with verified references.",
]
AGENT_ICONS = ["🧩", "🔭", "🧪", "📝"]

NAV = [("home", "🏠  Home"), ("search", "🔍  New Search"), ("projects", "📁  My Projects"),
       ("library", "📚  Research Library"), ("settings", "⚙️  Settings")]
NAV_ACTIVE = {"progress": "search", "results": "search", "proposal": "search"}

CSS = """
<style>
.block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1180px; }
h1,h2,h3,h4 { letter-spacing:-0.01em; color:#0f172a; }
/* sidebar */
section[data-testid="stSidebar"] { background: linear-gradient(180deg,#0f1b4c 0%,#0a1130 100%); }
section[data-testid="stSidebar"] * { color:#e2e8f0; }
section[data-testid="stSidebar"] .stButton > button {
  background:transparent; border:1px solid transparent; justify-content:flex-start; text-align:left;
  font-weight:500; padding:0.55rem 0.8rem; border-radius:10px; }
section[data-testid="stSidebar"] .stButton > button:hover { background:rgba(255,255,255,0.08); border-color:transparent; }
section[data-testid="stSidebar"] .stButton > button[kind="primary"],
section[data-testid="stSidebar"] .stButton > button[data-testid="stBaseButton-primary"] {
  background:#4338ca; color:#fff; }
.bb-brand { font-size:1.25rem; font-weight:700; color:#fff; margin:0.2rem 0 1.2rem 0.2rem; }
.bb-brand span { background:linear-gradient(90deg,#818cf8,#2dd4bf); -webkit-background-clip:text;
  -webkit-text-fill-color:transparent; }
.bb-side-foot { color:#94a3b8 !important; font-size:0.82rem; margin-top:1.5rem; line-height:1.4; }
.bb-pill-ok, .bb-pill-warn { display:inline-block; padding:2px 10px; border-radius:999px; font-size:0.74rem; margin-top:0.6rem; }
.bb-pill-ok { background:rgba(45,212,191,0.15); color:#5eead4 !important; border:1px solid #14b8a6; }
.bb-pill-warn { background:rgba(250,204,21,0.12); color:#fde047 !important; border:1px solid #ca8a04; }
/* full-width buttons everywhere (replaces deprecated use_container_width) */
.stButton > button, .stDownloadButton > button { width:100%; border-radius:10px; font-weight:600; }
/* hero */
.bb-hero { background:linear-gradient(120deg,#4f46e5 0%,#2563eb 45%,#14b8a6 100%); border-radius:18px;
  padding:2rem 2rem 1.6rem 2rem; color:#fff; margin-bottom:1rem; }
.bb-hero h1 { color:#fff; font-size:2.2rem; margin:0 0 0.4rem 0; }
.bb-hero p { color:rgba(255,255,255,0.92); max-width:44rem; margin:0; font-size:1.02rem; }
/* cards */
.bb-card { background:#fff; border:1px solid #e2e8f0; border-radius:14px; padding:1rem 1.15rem;
  margin-bottom:0.85rem; box-shadow:0 1px 2px rgba(15,23,42,0.04); }
.bb-card h4 { margin:0 0 0.4rem 0; font-size:1.02rem; }
.bb-card p { margin:0.25rem 0; }
.bb-muted { color:#64748b; font-size:0.9rem; }
.bb-tag { display:inline-block; padding:2px 10px; border-radius:999px; font-size:0.74rem; margin:0 6px 4px 0;
  background:#eef2ff; border:1px solid #c7d2fe; color:#3730a3; }
.bb-tag.teal { background:#ecfeff; border-color:#a5f3fc; color:#0e7490; }
.bb-limit { background:#fef2f2; border:1px solid #fecaca; border-left:4px solid #ef4444; border-radius:10px;
  padding:0.7rem 1rem; margin:0.6rem 0; color:#7f1d1d; }
.bb-limit ul { margin:0.3rem 0 0 1.1rem; padding:0; }
.bb-demo { background:#fffbeb; border:1px solid #fde68a; border-left:4px solid #f59e0b; border-radius:10px;
  padding:0.7rem 1rem; margin-bottom:0.9rem; color:#78350f; }
.bb-ok li { list-style:none; margin-left:-1.1rem; }
.bb-ok li::before { content:"✓ "; color:#16a34a; font-weight:700; }
/* agent steps */
.bb-step { display:flex; gap:0.9rem; align-items:flex-start; background:#fff; border:1px solid #e2e8f0;
  border-radius:14px; padding:0.95rem 1.1rem; margin-bottom:0.7rem; }
.bb-num { flex:0 0 2.1rem; height:2.1rem; border-radius:50%; display:flex; align-items:center; justify-content:center;
  font-weight:700; background:#e2e8f0; color:#475569; }
.bb-step.running { border-color:#a5b4fc; box-shadow:0 0 0 3px rgba(99,102,241,0.12); }
.bb-step.running .bb-num { background:#4f46e5; color:#fff; animation:bbpulse 1.2s infinite; }
.bb-step.completed .bb-num { background:#16a34a; color:#fff; }
.bb-step.failed { border-color:#fca5a5; } .bb-step.failed .bb-num { background:#dc2626; color:#fff; }
.bb-badge { margin-left:auto; font-size:0.74rem; font-weight:700; letter-spacing:0.04em; padding:2px 10px;
  border-radius:999px; background:#f1f5f9; color:#64748b; white-space:nowrap; }
.bb-step.running .bb-badge { background:#eef2ff; color:#4338ca; }
.bb-step.completed .bb-badge { background:#dcfce7; color:#166534; }
.bb-step.failed .bb-badge { background:#fee2e2; color:#991b1b; }
@keyframes bbpulse { 0%{box-shadow:0 0 0 0 rgba(79,70,229,.5)} 100%{box-shadow:0 0 0 10px rgba(79,70,229,0)} }
/* results */
.bb-sec { display:flex; align-items:center; gap:0.6rem; font-size:1.25rem; font-weight:700; color:#0f172a;
  margin:1.6rem 0 0.7rem 0; padding-bottom:0.4rem; border-bottom:2px solid #e2e8f0; }
.bb-sec span { display:inline-flex; align-items:center; justify-content:center; width:1.8rem; height:1.8rem;
  border-radius:50%; background:#4f46e5; color:#fff; font-size:0.95rem; }
.bb-label { display:inline-block; padding:2px 10px; border-radius:999px; font-size:0.78rem; font-weight:700; margin-right:6px; }
.bb-label.promising { background:#dcfce7; color:#166534; }
.bb-label.promising_with_modifications { background:#ecfccb; color:#3f6212; }
.bb-label.speculative { background:#fef9c3; color:#854d0e; }
.bb-label.poorly_supported { background:#fee2e2; color:#991b1b; }
.bb-src, .bb-ai { display:inline-block; padding:1px 8px; border-radius:6px; font-size:0.7rem; font-weight:700;
  letter-spacing:0.05em; margin-bottom:0.3rem; }
.bb-src { background:#e0f2fe; color:#075985; border:1px solid #bae6fd; }
.bb-ai { background:#f3e8ff; color:#6b21a8; border:1px solid #e9d5ff; }
.bb-card blockquote { margin:0.2rem 0 0.7rem 0; padding:0.3rem 0.8rem; border-left:3px solid #7dd3fc;
  color:#475569; font-size:0.9rem; background:#f8fafc; }
.bb-card details { margin-top:0.4rem; } .bb-card summary { cursor:pointer; color:#4338ca; font-size:0.88rem; }
/* mobile */
@media (max-width: 640px) {
  .block-container { padding-left:0.9rem; padding-right:0.9rem; }
  .bb-hero { padding:1.3rem 1.1rem; } .bb-hero h1 { font-size:1.6rem; }
  .bb-step { flex-wrap:wrap; }
}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)


# ------------------------------------------------------------------ helpers
def esc(x) -> str:
    return html.escape(str(x))


def tag(text: str, teal: bool = False) -> str:
    return f'<span class="bb-tag{" teal" if teal else ""}">{esc(text)}</span>'


def when(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%d %b %Y, %H:%M")


def init_state() -> None:
    ss = st.session_state
    ss.setdefault("page", "home")
    ss.setdefault("result", None)
    ss.setdefault("run_pending", False)
    ss.setdefault("run_args", {})
    ss.setdefault("proposal_md", None)
    ss.setdefault("edit_mode", False)
    for k in ("problem_in", "source_in", "constraints_in"):
        ss.setdefault(k, "")


def go(page: str) -> None:
    st.session_state.page = page
    if page != "progress":
        st.session_state.run_pending = False  # leaving the progress screen cancels a queued run
    st.rerun()


def set_result(res: RunResult) -> None:
    st.session_state.result = res
    st.session_state.proposal_md = None
    st.session_state.edit_mode = False
    st.session_state.pop("proposal_editor", None)
    st.session_state.pop("sel_cand", None)


def apply_example(label: str) -> None:
    ex = EXAMPLE_PROBLEMS.get(label)
    if ex:
        st.session_state.problem_in = ex["problem"]
        st.session_state.source_in = ex["source"]
        st.session_state.constraints_in = ex["constraints"]


def example_chips(prefix: str) -> None:
    st.caption("Try these examples")
    labels = list(EXAMPLE_PROBLEMS)
    for row in range(0, len(labels), 3):
        cols = st.columns(3)
        for col, label in zip(cols, labels[row : row + 3]):
            col.button(label, key=f"{prefix}_ex_{label}", on_click=apply_example, args=(label,))


def launch(problem: str, source: str, constraints: str) -> None:
    problem = problem.strip()
    if len(problem) < 15:
        st.error("Please describe your problem in at least a sentence (15+ characters).")
        return
    if ISSUES:
        st.error("Live mode needs configuration: " + " ".join(ISSUES) +
                 " Meanwhile you can open a cached demonstration from the Home or My Projects screens.")
        return
    st.session_state.run_args = dict(problem=problem, source=source.strip(), constraints=constraints.strip())
    st.session_state.run_pending = True
    go("progress")


def best_match(res: RunResult):
    pairs = candidate_pairs(res)
    return pairs[0] if pairs else (None, None)


def run_title(res: RunResult) -> str:
    return res.proposal.title if res.proposal else (res.problem[:80] + ("..." if len(res.problem) > 80 else ""))


def steps_html(states: list[str], msgs: list[str]) -> str:
    out = []
    for i, name in enumerate(AGENT_NAMES):
        s = states[i]
        mark = {"completed": "✓", "failed": "!"}.get(s, str(i + 1))
        out.append(
            f'<div class="bb-step {s}"><div class="bb-num">{mark}</div>'
            f'<div><b>{AGENT_ICONS[i]} {esc(name)}</b><br><span class="bb-muted">{esc(AGENT_BLURBS[i])}</span>'
            + (f'<br><span>{esc(msgs[i])}</span>' if msgs[i] else "")
            + f'</div><div class="bb-badge">{s.upper()}</div></div>'
        )
    return "".join(out)


def banners(res: RunResult) -> None:
    if res.is_demo:
        st.markdown(
            '<div class="bb-demo"><b>Cached demonstration.</b> This is a precomputed example, not a live '
            "search. Papers are real, but the analysis was written in advance and not re-verified in this "
            "session.</div>", unsafe_allow_html=True)
    if res.error:
        st.error(res.error)
    for w in res.warnings:
        if w.startswith("DEMONSTRATION"):
            st.caption(w)
        else:
            st.warning(w)


# ------------------------------------------------------------------ config + sidebar
init_state()
SETTINGS = load_settings()
ISSUES = SETTINGS.problems()

with st.sidebar:
    st.markdown('<div class="bb-brand">🧬 <span>BioBridge</span></div>', unsafe_allow_html=True)
    active = NAV_ACTIVE.get(st.session_state.page, st.session_state.page)
    for pid, label in NAV:
        if st.button(label, key=f"nav_{pid}", type="primary" if pid == active else "secondary"):
            go(pid)
    st.markdown(
        '<div class="bb-side-foot">Think beyond boundaries.</div>'
        + ('<span class="bb-pill-warn">Live mode not configured</span>' if ISSUES
           else '<span class="bb-pill-ok">Live mode ready</span>'),
        unsafe_allow_html=True)


# ------------------------------------------------------------------ pages
def page_home() -> None:
    st.markdown(
        '<div class="bb-hero"><h1>Find solutions beyond your field.</h1>'
        "<p>Turn any research challenge into a cross-disciplinary opportunity with four AI agents "
        "that search real papers across fields and test whether the idea transfers.</p></div>", unsafe_allow_html=True)
    with st.container(border=True):
        c1, c2 = st.columns([5, 1])
        c1.text_input("What problem are you trying to solve?", key="problem_in",
                      placeholder="Describe the problem you want to solve...")
        c2.markdown("<div style='height:1.75rem'></div>", unsafe_allow_html=True)
        if c2.button("Start →", key="home_start", type="primary"):
            launch(st.session_state.problem_in, st.session_state.source_in, st.session_state.constraints_in)
    example_chips("home")

    st.subheader("How it works")
    cols = st.columns(4)
    for i, col in enumerate(cols):
        col.markdown(
            f'<div class="bb-card"><h4>{AGENT_ICONS[i]} {i + 1}. {AGENT_NAMES[i]}</h4>'
            f'<p class="bb-muted">{esc(AGENT_BLURBS[i])}</p></div>', unsafe_allow_html=True)

    runs = cache.list_runs()[:3]
    if runs:
        st.subheader("Recent projects")
        for r in runs:
            project_row(r["key"], r["result"], r["mtime"], "run", "home")
    examples = cache.list_examples()
    if examples:
        st.subheader("Cached demonstrations")
        st.caption("No API key and no internet needed.")
        cols = st.columns(min(3, len(examples)))
        for col, (name, title) in zip(cols, examples.items()):
            col.markdown(f'<div class="bb-card"><h4>{esc(title)}</h4></div>', unsafe_allow_html=True)
            if col.button("Open demonstration", key=f"home_demo_{name}"):
                set_result(cache.load_example(name))
                go("results")


def page_search() -> None:
    st.title("New search")
    st.caption("Describe a hard problem. Source field and constraints are optional but make the analysis sharper.")
    example_chips("search")
    st.text_area("Problem", key="problem_in", height=130, placeholder="Describe the problem you want to solve...")
    c1, c2 = st.columns(2)
    c1.text_input("Source field (optional)", key="source_in", placeholder="e.g. Robotics")
    c2.text_input("Constraints (optional)", key="constraints_in", placeholder="cost, time, hardware, safety, difficulty")
    if ISSUES:
        st.warning("Live mode is not configured yet:\n\n" + "\n".join(f"- {i}" for i in ISSUES)
                   + "\n\nOpen the Settings screen for step-by-step help. Cached demonstrations still work.")
    if st.button("Build the Bridge", key="search_go", type="primary"):
        launch(st.session_state.problem_in, st.session_state.source_in, st.session_state.constraints_in)


def page_progress() -> None:
    ss = st.session_state
    args = ss.run_args
    head, cancel = st.columns([5, 1])
    title = args.get("problem", "") or (ss.result.problem if ss.result else "")
    head.subheader(title[:110] + ("..." if len(title) > 110 else "") or "Agent workflow")
    head.caption("The four agents are working together to find cross-disciplinary insights...")
    if cancel.button("Cancel", key="cancel_run"):
        go("search" if ss.run_pending else "home")

    holder = st.empty()
    if ss.run_pending:
        states, msgs = ["waiting"] * 4, [""] * 4
        holder.markdown(steps_html(states, msgs), unsafe_allow_html=True)

        def on_status(i: int, state: str, msg: str) -> None:
            states[i], msgs[i] = state, msg
            holder.markdown(steps_html(states, msgs), unsafe_allow_html=True)

        try:
            SETTINGS.validate()
            res = run_pipeline(args["problem"], args["source"], args["constraints"], SETTINGS, on_status=on_status)
        except ConfigError as exc:
            st.error(str(exc))
            ss.run_pending = False
            return
        ss.run_pending = False
        set_result(res)
        if not res.error:
            go("results")
        # on failure fall through: show the error and the retry options below

    res: RunResult | None = ss.result
    if res is None:
        st.info("No search is running. Start one from the Home or New Search screen.")
        if st.button("Go to New Search", key="prog_new"):
            go("search")
        return
    holder.markdown(steps_html([a.state for a in res.agents], [a.message for a in res.agents]), unsafe_allow_html=True)
    if res.error:
        st.error(res.error)
        c1, c2 = st.columns(2)
        if c1.button("Edit and retry", key="prog_retry"):
            apply_inputs(res)
            go("search")
        if c2.button("Open a cached demonstration", key="prog_demo"):
            go("home")
        if res.abstraction is not None and st.button("View partial results", key="prog_partial"):
            go("results")  # whatever finished before the failure is kept and shown
    else:
        if st.button("View results →", key="prog_results", type="primary"):
            go("results")


def apply_inputs(res: RunResult) -> None:
    st.session_state.problem_in = res.problem
    st.session_state.source_in = res.source_field_input
    st.session_state.constraints_in = res.constraints_input


def ul(items, cls: str = "") -> str:
    items = [x for x in items if str(x).strip()]
    if not items:
        return '<p class="bb-muted">None stated.</p>'
    return f'<ul class="{cls}">' + "".join(f"<li>{esc(x)}</li>" for x in items) + "</ul>"


def link(url: str, text: str) -> str:
    return f'<a href="{esc(url)}" target="_blank" rel="noopener">{esc(text)} ↗</a>'


def label_badge(label: str) -> str:
    return f'<span class="bb-label {esc(label)}">{esc(LABEL_TEXT.get(label, label))}</span>'


SRC_BADGE = '<span class="bb-src">REPORTED BY THE PAPER</span>'
AI_BADGE = '<span class="bb-ai">AI INTERPRETATION</span>'


def paper_ids_html(p) -> str:
    """Identifiers exactly as retrieved; anything missing is said to be unavailable, never guessed."""
    parts = []
    if p.arxiv_id:
        parts.append(link(f"https://arxiv.org/abs/{p.arxiv_id}", f"arXiv:{p.arxiv_id}"))
    if p.doi:
        parts.append(link(f"https://doi.org/{p.doi}", f"DOI:{p.doi}"))
    else:
        parts.append('<span class="bb-muted">DOI unavailable</span>')
    if not p.arxiv_id:
        parts.append(f'<span class="bb-muted">ID {esc(p.paper_id)}</span>')
    return " · ".join(parts)


def paper_card(p, relevance: bool = False) -> str:
    year = p.year or "year unavailable"
    rel = ""
    if relevance and p.similarity_raw is not None:
        rel = (f'<p class="bb-muted">Retrieval relevance (embedding similarity {p.similarity_raw:.2f}): used only to '
               "choose which papers to read. It measures wording closeness, not scientific validity.</p>")
    return (
        f'<div class="bb-card"><h4>{esc(p.title)}</h4>'
        f'<p class="bb-muted">{esc(p.authors_short(6))} · {esc(year)} · {esc(p.source)}</p>'
        f'{tag(p.target_field) if p.target_field else ""}'
        f'<p>{paper_ids_html(p)} · {link(p.url, "Open original source")}</p>{rel}'
        f'<details><summary>Abstract (as retrieved from {esc(p.source)}; the full paper was not read)</summary>'
        f'<p class="bb-muted">{esc(p.abstract)}</p></details></div>')


def claim_block(title: str, claims) -> str:
    if not claims:
        return f"<p><b>{esc(title)}:</b> <span class='bb-muted'>not stated in the retrieved abstract.</span></p>"
    out = f"<p><b>{esc(title)}</b></p>"
    for c in claims:
        out += f'<p>{esc(c.statement)}</p><blockquote>“{esc(c.quote)}”</blockquote>'
    return out


def candidate_pairs(res: RunResult):
    """[(Evaluation, Paper)] for the connections carried forward (up to three)."""
    ids = res.candidate_ids or [e.paper_id for e in select_candidates(res.evaluations)]
    ev_by, p_by = {e.paper_id: e for e in res.evaluations}, {p.paper_id: p for p in res.papers}
    return [(ev_by[i], p_by[i]) for i in ids if i in ev_by and i in p_by]


def score_text(ev) -> str:
    s = f"about {ev.transferability_score:g} / 10"
    return s + ("" if ev.score_reliable else " (low reliability: nothing could be verified)")


def section(n: int, title: str) -> None:
    st.markdown(f'<div class="bb-sec"><span>{n}</span>{esc(title)}</div>', unsafe_allow_html=True)


def sec_problem(res: RunResult) -> None:
    section(1, "Problem understanding")
    a = res.abstraction
    st.markdown(f'<div class="bb-card"><b>Your problem</b><p>{esc(res.problem)}</p></div>', unsafe_allow_html=True)
    if a is None:
        st.info("The problem could not be decomposed (the Abstractor did not finish).")
        return
    l, r = st.columns(2)
    l.markdown(f'<div class="bb-card"><b>Objective</b><p>{esc(a.objective or "Not extracted (saved by an earlier version).")}</p>'
               f"<b>Constraints</b>{ul(a.constraints)}</div>", unsafe_allow_html=True)
    r.markdown(f'<div class="bb-card"><b>Underlying structure</b><p>{esc(a.abstract_description)}</p>'
               f"<b>Mechanisms</b>{ul(a.mechanisms)}<b>Variables</b>{ul(a.variables)}</div>", unsafe_allow_html=True)
    with st.expander(f"Research directions searched ({len(a.bridge_queries)})"):
        st.caption("Each direction probes one objective, constraint or mechanism, wherever it is studied.")
        for q in a.bridge_queries:
            st.markdown(
                f'<div class="bb-card"><h4>{esc(q.target_field)}</h4>' + "".join(tag(k) for k in q.keywords)
                + (f'<p class="bb-muted">Probes: {esc(q.mechanism_targeted)}</p>' if q.mechanism_targeted else "")
                + f'<p class="bb-muted">Query: {esc(q.search_query)}</p><p>{esc(q.rationale)}</p></div>',
                unsafe_allow_html=True)


def sec_discoveries(res: RunResult, pairs) -> int:
    section(2, "Cross-domain discoveries")
    if not pairs:
        st.markdown('<div class="bb-limit"><b>No supported connection.</b> '
                    + esc(res.insufficient_reason or "No candidate connection is available for this run.")
                    + "</div>", unsafe_allow_html=True)
        return -1
    st.caption(f"{len(pairs)} supported connection{'s' if len(pairs) > 1 else ''}, ranked. "
               "Fewer than three is normal: Bio-Bridge shows only what the retrieved research supports.")
    for n, (ev, p) in enumerate(pairs, 1):
        st.markdown(
            f'<div class="bb-card"><b>#{n}</b> {label_badge(ev.label)} {tag(p.target_field or "field n/a")}'
            f'<h4>{esc(p.title)}</h4>'
            f'<p><b>Shared mechanism.</b> {esc(ev.mechanism_extracted)}</p>'
            f'<p class="bb-muted">Transferability {esc(score_text(ev))} · Main uncertainty: {esc(ev.main_uncertainty)}</p></div>',
            unsafe_allow_html=True)
    if len(pairs) == 1:
        return 0
    return st.radio("Inspect connection", list(range(len(pairs))), horizontal=True, key="sel_cand",
                    format_func=lambda i: f"#{i + 1} {pairs[i][1].title[:48]}")


def sec_evidence(ev, p) -> None:
    section(3, "Research evidence")
    st.markdown(paper_card(p, relevance=True), unsafe_allow_html=True)
    st.markdown(
        f'<div class="bb-card">{SRC_BADGE}<p class="bb-muted">Statements below are kept only if their quoted words '
        "were found in the retrieved abstract. This checks that the words exist, not that the paper is right.</p>"
        + claim_block("Objective", [ev.paper_objective] if ev.paper_objective else [])
        + claim_block("Method", [ev.paper_method] if ev.paper_method else [])
        + claim_block("Findings", ev.reported_findings)
        + claim_block("Limitations reported by the authors", ev.reported_limitations)
        + f'<p class="bb-muted">{esc(ev.verification_note)}</p></div>', unsafe_allow_html=True)
    st.markdown(f'<div class="bb-card">{AI_BADGE}<p><b>Mechanism Bio-Bridge extracted.</b> {esc(ev.mechanism_extracted)}</p></div>',
                unsafe_allow_html=True)


def sec_match(ev) -> None:
    section(4, "Why it matches")
    st.markdown(f'<div class="bb-card">{AI_BADGE}<p><b>Shared structure.</b> {esc(ev.shared_structure)}</p></div>',
                unsafe_allow_html=True)
    if ev.mappings:
        st.table([{"Your problem": m.problem_concept, "In the paper": m.paper_concept, "Note": m.note}
                  for m in ev.mappings])
    st.markdown(f'<div class="bb-card"><b>Transferability: {esc(score_text(ev))}</b> {label_badge(ev.label)}'
                f'<p>{esc(ev.score_rationale)}</p><p><b>Main uncertainty.</b> {esc(ev.main_uncertainty)}</p>'
                '<p class="bb-muted">A ranking aid for comparing candidates, not the probability that it will work.</p></div>',
                unsafe_allow_html=True)
    cols = st.columns(5)
    for col, (key, w) in zip(cols, WEIGHTS.items()):
        v = getattr(ev.scores, key)
        col.metric(key.replace("_", " ").capitalize(), f"{v:g} / 10")
        col.progress(min(1.0, max(0.0, v / 10)))
        col.caption(f"weight {w:.0%}")
    for n in ev.score_notes:
        st.caption("Adjusted by software: " + n)
    with st.expander("How the score and label are decided"):
        st.write(EXPLANATION)
        for key, text in CRITERIA_TEXT.items():
            st.markdown(f"- **{key.replace('_', ' ').capitalize()}**: {text}")
        st.markdown("**Labels.** Promising: strong fit as is. Promising with modifications: real fit once the "
                    "listed changes are made. Speculative: plausible but weakly supported. Poorly supported: "
                    "no real transfer. Software only ever lowers a label that the numbers do not justify.")


def sec_risks(ev) -> None:
    section(5, "Limitations and transfer risks")
    l, r = st.columns(2)
    l.markdown(f'<div class="bb-limit"><b>What may not transfer</b>{ul(ev.differences)}</div>', unsafe_allow_html=True)
    r.markdown(f'<div class="bb-card"><b>Assumptions</b>{ul(ev.assumptions)}</div>', unsafe_allow_html=True)
    if ev.risks:
        st.table([{"Transfer risk": x.risk, "Possible mitigation": x.mitigation or "none suggested"} for x in ev.risks])


def sec_adaptation(res: RunResult, ev) -> None:
    section(6, "Proposed adaptation")
    l, r = st.columns(2)
    l.markdown(f'<div class="bb-card">{AI_BADGE}<br><b>Reuse</b>{ul(ev.what_transfers, "bb-ok")}</div>', unsafe_allow_html=True)
    r.markdown(f'<div class="bb-card">{AI_BADGE}<br><b>Modify</b>{ul(ev.needs_modification)}</div>', unsafe_allow_html=True)
    pr = res.proposal
    if pr and pr.adaptation:
        a = pr.adaptation
        st.markdown(f'<div class="bb-card"><b>In the proposal</b> {AI_BADGE}<p>{esc(a.how_it_addresses_problem)}</p>'
                    f"<b>Reuse</b>{ul(a.reuse)}<b>Modify</b>{ul(a.modify)}</div>", unsafe_allow_html=True)
    elif pr is None:
        st.caption("No proposal was written for this run.")


def sec_validation(res: RunResult) -> None:
    section(7, "Validation plan")
    pr = res.proposal
    if pr is None or pr.validation_plan is None:
        st.info("No validation plan: the proposal stage did not produce one for this run.")
        return
    v = pr.validation_plan
    st.markdown(f'<div class="bb-card">{AI_BADGE}<p><b>Testable hypothesis.</b> {esc(pr.hypothesis)}</p>'
                f"<p><b>Baseline.</b> {esc(v.baseline)}</p></div>", unsafe_allow_html=True)
    a, b, c = st.columns(3)
    a.markdown(f'<div class="bb-card"><b>Metrics</b>{ul(v.metrics)}</div>', unsafe_allow_html=True)
    b.markdown(f'<div class="bb-card"><b>Required data</b>{ul(v.required_data)}</div>', unsafe_allow_html=True)
    c.markdown(f'<div class="bb-limit"><b>Failure conditions</b>{ul(v.failure_conditions)}</div>', unsafe_allow_html=True)
    if pr.experiments:
        with st.expander(f"Suggested experiments ({len(pr.experiments)})"):
            for x in pr.experiments:
                st.markdown(f"**{x.name}**: {x.description}")
                if x.baselines:
                    st.caption("Baselines: " + ", ".join(x.baselines))
                if x.metrics:
                    st.caption("Metrics: " + ", ".join(x.metrics))


def sec_references(res: RunResult, pairs) -> None:
    section(8, "References")
    pr = res.proposal
    if pr and pr.references:
        for r in pr.references:
            ids = []
            if r.arxiv_id:
                ids.append(link(f"https://arxiv.org/abs/{r.arxiv_id}", f"arXiv:{r.arxiv_id}"))
            if r.doi:
                ids.append(link(f"https://doi.org/{r.doi}", f"DOI:{r.doi}"))
            authors = ", ".join(r.authors[:4]) + (" et al." if len(r.authors) > 4 else "") if r.authors else "Authors unavailable"
            st.markdown(
                f'<div class="bb-card"><b>{esc(r.title)}</b><p class="bb-muted">{esc(authors)} · '
                f'{esc(r.year or "year unavailable")} · {esc(r.source)} · [{esc(r.paper_id)}]</p>'
                f'<p>{" · ".join(ids + [link(r.url, "Original source")])}</p></div>', unsafe_allow_html=True)
        st.caption("Every reference was matched to a record retrieved from arXiv or Semantic Scholar. "
                   "Only abstracts were read, so none of these is a full-paper review.")
    elif pairs:
        st.caption("No proposal was written, so these are the candidate papers.")
        for _, p in pairs:
            st.markdown(paper_card(p), unsafe_allow_html=True)
    else:
        st.info("No references: no supported connection was found.")


def page_results() -> None:
    res: RunResult | None = st.session_state.result
    if res is None:
        st.info("Nothing to show yet. Start a new search or open a project.")
        if st.button("New search", key="res_new"):
            go("search")
        return
    top_c, _ = st.columns([1, 3])
    if top_c.button("← New search", key="res_back"):
        go("search")
    banners(res)
    st.title("Cross-domain insight" if candidate_pairs(res) else "Research results")

    # On-demand live metadata verification. Results are derived from source API responses, not an LLM label.
    report_key = f"verification:{id(res)}"
    with st.container(border=True):
        vc1, vc2 = st.columns([3, 1])
        with vc1:
            st.subheader("Evidence verification")
            st.caption("Checks source identity and metadata separately from whether scientific claims are true.")
        with vc2:
            if st.button("Verify Evidence", key="verify_evidence", type="primary", disabled=not bool(res.papers)):
                with st.spinner("Checking retrieved records against source metadata…"):
                    st.session_state[report_key] = verify_sources(res.papers, res.evaluations, timeout=load_settings().request_timeout)
        report = st.session_state.get(report_key)
        if report:
            sm = report["summary"]
            a, b, c, d = st.columns(4)
            a.metric("Sources checked", sm["sources_checked"])
            b.metric("Records matched", sm["source_records_matched"])
            c.metric("Claims assessed", sm["claims_assessed"])
            d.metric("Excerpts matched", sm["excerpts_matched"])
            st.caption("Checked at " + report["checked_at"] + ". " + report["scope_note"])
            with st.expander("Detailed verification report", expanded=False):
                for item in report["sources"]:
                    st.markdown(f"**{item['title']}** — {item['status'].replace('_', ' ').title()}")
                    for check in item["checks"]:
                        st.write(f"• {check['name'].replace('_', ' ').title()}: {check['status'].replace('_', ' ')} — {check['detail']}")
                st.markdown("**Claim excerpt checks**")
                if not report["claims"]:
                    st.caption("No source-attributed claims were available to assess.")
                for claim in report["claims"]:
                    with st.expander(f"{claim['status'].replace('_', ' ').title()}: {claim['claim'][:110]}"):
                        st.write("Source:", claim["paper_id"])
                        st.write("Method:", claim["method"])
                        if claim["excerpt"]:
                            st.code(claim["excerpt"])
                        st.caption(claim["limitation"])
            st.download_button("Download verification report (JSON)", __import__('json').dumps(report, indent=2),
                                file_name="bio_bridge_verification_report.json", mime="application/json", key="dl_verification")
        else:
            st.caption("Not run yet. Source metadata will be checked against arXiv or Semantic Scholar when you select Verify Evidence.")

    pairs = candidate_pairs(res)
    sec_problem(res)
    sel = sec_discoveries(res, pairs)
    if sel >= 0:
        ev, p = pairs[min(sel, len(pairs) - 1)]
        sec_evidence(ev, p)
        sec_match(ev)
        sec_risks(ev)
        sec_adaptation(res, ev)
    sec_validation(res)
    sec_references(res, pairs)

    st.divider()
    if res.proposal and st.button("Open the full proposal →", key="res_to_proposal", type="primary"):
        go("proposal")
    cand_ids = {p.paper_id for _, p in pairs}
    titles = {p.paper_id: p.title for p in res.papers}
    rejected = [e for e in res.evaluations if e.paper_id not in cand_ids]
    if rejected:
        with st.expander(f"Evaluated but not carried forward ({len(rejected)})"):
            for e in rejected:
                st.markdown(f"**{titles.get(e.paper_id, e.paper_id)}**: {LABEL_TEXT[e.label]}, "
                            f"about {e.transferability_score:g} / 10")
                st.caption(e.score_rationale)
                st.caption("Main uncertainty: " + e.main_uncertainty)
    if res.papers:
        with st.expander(f"All retrieved papers ({len(res.papers)})"):
            st.caption("Ordered by embedding similarity to the problem, a retrieval step only. "
                       "Similarity is not evidence that a mechanism transfers.")
            for p in res.papers:
                st.markdown(paper_card(p, relevance=True), unsafe_allow_html=True)
    if res.abstraction:
        st.download_button("Download analysis trace (JSON)", res.model_dump_json(indent=2),
                           file_name="bio_bridge_trace.json", mime="application/json", key="dl_json")


def page_proposal() -> None:
    ss = st.session_state
    res: RunResult | None = ss.result
    if res is None or res.proposal is None or res.abstraction is None:
        st.info("There is no proposal yet. Run a search first, or open a project that has one.")
        if st.button("New search", key="prop_new"):
            go("search")
        return
    pr = res.proposal
    b, _ = st.columns([1, 3])
    if b.button("← Back to results", key="prop_back"):
        go("results")
    banners(res)
    h, e = st.columns([4, 1])
    h.header("Research proposal")
    h.caption(pr.title)
    if e.button("Done editing" if ss.edit_mode else "✏️ Edit", key="toggle_edit"):
        ss.edit_mode = not ss.edit_mode
        st.rerun()
    st.markdown('<div class="bb-demo"><b>Evidence basis.</b> '
                + esc(pr.evidence_basis or "Based on retrieved abstracts only; not independently verified.")
                + "</div>", unsafe_allow_html=True)

    default_md = proposal_to_markdown(pr, res.problem, res.abstraction)
    if ss.proposal_md is None:
        ss.proposal_md = default_md

    if ss.edit_mode:
        ss.proposal_md = st.text_area("Edit the proposal (Markdown). Your changes are used for the download.",
                                      value=ss.proposal_md, height=560, key="proposal_editor")
    else:
        left, right = st.columns(2)
        with left:
            st.markdown(f'<div class="bb-card"><b>Executive summary</b><p>{esc(pr.executive_summary)}</p>'
                        f"<p><b>Hypothesis.</b> {esc(pr.hypothesis)}</p>"
                        f"<p><b>Evidence statement.</b> {esc(pr.evidence_statement)}</p></div>", unsafe_allow_html=True)
            if pr.adaptation:
                a = pr.adaptation
                st.markdown(f'<div class="bb-card"><b>Proposed adaptation</b><p>{esc(a.how_it_addresses_problem)}</p>'
                            f"<b>Reuse</b>{ul(a.reuse)}<b>Modify</b>{ul(a.modify)}</div>", unsafe_allow_html=True)
            steps = "".join(f"<li>{esc(m)}</li>" for m in pr.methodology)
            st.markdown(f'<div class="bb-card"><b>Methodology</b><ol>{steps}</ol>'
                        f'<p class="bb-muted">{esc(pr.variables_and_updates)}</p></div>', unsafe_allow_html=True)
        with right:
            if pr.validation_plan:
                v = pr.validation_plan
                st.markdown(f'<div class="bb-card"><b>Validation plan</b><p><b>Baseline.</b> {esc(v.baseline)}</p>'
                            f"<b>Metrics</b>{ul(v.metrics)}<b>Required data</b>{ul(v.required_data)}</div>"
                            f'<div class="bb-limit"><b>Failure conditions</b>{ul(v.failure_conditions)}</div>',
                            unsafe_allow_html=True)
            st.markdown(f'<div class="bb-card"><b>Expected outcomes (hypothesised)</b>{ul(pr.expected_outcomes, "bb-ok")}</div>',
                        unsafe_allow_html=True)
            st.markdown(f'<div class="bb-limit"><b>Risks and limitations</b>{ul(pr.risks + pr.limitations_and_assumptions)}</div>',
                        unsafe_allow_html=True)
        st.subheader("References")
        for r in pr.references:
            st.markdown(f"- {reference_line(r)}")
        with st.expander("Full proposal text (Markdown)"):
            st.markdown(ss.proposal_md)
    d1, d2 = st.columns(2)
    d1.download_button("Download proposal (Markdown)", ss.proposal_md, file_name="bio_bridge_proposal.md",
                       mime="text/markdown", key="dl_md")
    d2.download_button("Download analysis trace (JSON)", res.model_dump_json(indent=2),
                       file_name="bio_bridge_trace.json", mime="application/json", key="dl_json_prop")


def project_row(key: str, res: RunResult, ts: float, kind: str, where: str) -> None:
    ev, paper = best_match(res)
    tags = tag(res.abstraction.source_field) if res.abstraction else ""
    if paper:
        tags += tag(paper.target_field, True)
    status = "Demonstration" if kind == "demo" else ("Completed" if res.proposal else "No match")
    if kind == "run":
        c1, c2, c3 = st.columns([6, 1.3, 1.1])
    else:
        (c1, c2), c3 = st.columns([6, 1.3]), None
    c1.markdown(
        f'<div class="bb-card"><b>{esc(run_title(res))}</b><br>{tags}{tag(status, True)}'
        f'<br><span class="bb-muted">{"Last updated " + when(ts) if ts else "Bundled example"}</span></div>',
        unsafe_allow_html=True)
    if c2.button("Open", key=f"open_{where}_{kind}_{key}"):
        set_result(res)
        go("results")
    if kind == "run" and c3.button("Delete", key=f"del_{where}_{key}"):
        cache.delete_run(key)
        st.rerun()


def page_projects() -> None:
    st.title("My projects")
    runs = cache.list_runs()
    demos = []
    for name, _title in cache.list_examples().items():
        try:
            demos.append((name, cache.load_example(name)))
        except Exception:
            continue
    tab_all, tab_runs, tab_demo = st.tabs([f"All ({len(runs) + len(demos)})", f"My runs ({len(runs)})",
                                           f"Demonstrations ({len(demos)})"])
    with tab_all:
        if not runs and not demos:
            st.info("Nothing here yet. Completed live runs are saved automatically and appear in this list.")
        for r in runs:
            project_row(r["key"], r["result"], r["mtime"], "run", "all")
        for name, res in demos:
            project_row(name, res, 0, "demo", "all")
    with tab_runs:
        if not runs:
            st.info("No saved runs yet. Completed live runs are saved on this computer in data/cache.")
        for r in runs:
            project_row(r["key"], r["result"], r["mtime"], "run", "runs")
    with tab_demo:
        if not demos:
            st.info("No bundled demonstrations were found in data/examples.")
        for name, res in demos:
            project_row(name, res, 0, "demo", "demo")


def page_library() -> None:
    st.title("Research library")
    st.caption("Every real paper retrieved in your saved runs and demonstrations, in one place.")
    papers: dict[str, dict] = {}

    def add(res: RunResult) -> None:
        for p in res.papers:
            d = papers.setdefault(p.paper_id, {"paper": p, "n": 0})
            d["n"] += 1

    for r in cache.list_runs():
        add(r["result"])
    for name in cache.list_examples():
        try:
            add(cache.load_example(name))
        except Exception:
            continue
    cur = st.session_state.result
    if cur is not None and not cur.is_demo:
        for p in cur.papers:
            papers.setdefault(p.paper_id, {"paper": p, "n": 1})
    if not papers:
        st.info("The library is empty. Papers appear here after your first search.")
        return
    c1, c2 = st.columns([3, 2])
    q = c1.text_input("Search the library", key="lib_q", placeholder="title or keyword").strip().lower()
    fields = sorted({d["paper"].target_field for d in papers.values() if d["paper"].target_field})
    field = c2.selectbox("Field", ["All fields"] + fields, key="lib_field")
    shown = [d for d in papers.values()
             if (field == "All fields" or d["paper"].target_field == field)
             and (not q or q in d["paper"].title.lower() or q in d["paper"].abstract.lower())]
    st.caption(f"{len(shown)} of {len(papers)} papers")
    for d in sorted(shown, key=lambda d: (d["paper"].year or 0), reverse=True):
        p = d["paper"]
        st.markdown(paper_card(p), unsafe_allow_html=True)
        st.caption(f"In {d['n']} saved project(s)")


def page_settings() -> None:
    st.title("Settings")
    st.subheader("Gemini (free tier)")
    if ISSUES:
        st.warning("Live mode is not configured yet:\n\n" + "\n".join(f"- {i}" for i in ISSUES))
        st.markdown(
            "1. Create a free key at [Google AI Studio](https://aistudio.google.com/apikey).\n"
            "2. Open the `.env` file in the Bio-Bridge folder with Notepad.\n"
            "3. Put it after `GEMINI_API_KEY=` and check `MODEL=` against the free-tier column on the "
            "[Gemini pricing page](https://ai.google.dev/gemini-api/docs/pricing).\n"
            "4. Save, then close and reopen Bio-Bridge (double-click `Start_BioBridge.bat`).")
    else:
        st.success("Gemini API key found and model set. (The key itself is never displayed.)")
    st.markdown(f"- **Model:** `{SETTINGS.model or 'not set'}`\n"
                f"- **Semantic Scholar key:** {'configured' if SETTINGS.s2_api_key else 'not set (optional)'}\n"
                f"- **Embedding model:** `{SETTINGS.embed_model}` (runs locally; first use downloads about 100 MB)\n"
                f"- **Limits:** {SETTINGS.max_papers_per_search} papers per search, rerank {SETTINGS.rerank_limit}, "
                f"shortlist {SETTINGS.shortlist_limit}")
    st.caption("The free tier has per-minute and per-day limits that can change, so a run can be refused. "
               "The app tells you when that happens. Free-tier content may be used by Google to improve its "
               "products, so do not enter confidential data.")
    st.subheader("Saved runs")
    n = len(cache.list_runs())
    st.write(f"{n} saved run(s) in `data/cache` on this computer. Repeating the same input reuses a saved run "
             "and costs no API quota.")
    if st.button("Clear saved runs", key="clear_cache", disabled=n == 0):
        for r in cache.list_runs():
            cache.delete_run(r["key"])
        st.success("Saved runs cleared.")
        st.rerun()


PAGES = {
    "home": page_home, "search": page_search, "progress": page_progress, "results": page_results,
    "proposal": page_proposal, "projects": page_projects, "library": page_library, "settings": page_settings,
}
PAGES.get(st.session_state.page, page_home)()
