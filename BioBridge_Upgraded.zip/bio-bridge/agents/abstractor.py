"""Agent 1: decompose the problem into objective, constraints, variables and mechanisms, then plan searches."""
from __future__ import annotations

from config import Settings
from llm import call_json
from schemas import Abstraction, AbstractionOut

SYSTEM = """You are the Abstractor in a cross-disciplinary research tool. You do NOT search or judge papers.
Decompose the user's problem, independent of whatever discipline it is phrased in:
- objective: what must be achieved or optimised, in one plain sentence.
- constraints: the conditions that limit any solution (resources, information available, safety, scale,
  timescale, noise). Include the user's constraints and any you can infer from the problem.
- variables: the quantities that are measured, controlled or traded off.
- mechanisms: the underlying processes or dynamics the problem involves (e.g. "local signalling with
  decay", "competition for a shared resource", "phase transition under accumulating damage").
- math_primitives: the formal structure (e.g. "decentralised consensus on a graph", "change-point detection").
- abstract_description: the problem restated WITHOUT domain jargon, in terms of that structure.
- research_directions (field `bridge_queries`): 3 to 6 literature searches. Each probes ONE objective,
  constraint or mechanism listed above (say which in `mechanism_targeted`) and names the scientific or
  technical field where that mechanism is studied (`target_field`). Choose fields because the mechanism
  is studied there, not to look exotic. A direction may sit in the user's own field if that is where the
  mechanism is best studied. Use fewer than 6 when fewer are justified; do not pad. Each needs 2-5
  keywords, a distinct short `search_query` (3-8 words, arXiv-friendly) and a one-sentence rationale.
- source_field: a label for the discipline the problem comes from. The user's stated field is only a
  hint for this label; do not let it narrow the decomposition or the searches.
Do not invent papers, authors or results. Return JSON only."""


def abstract_problem(problem: str, source_field: str, constraints: str, settings: Settings, client=None) -> Abstraction:
    user = (
        f"<problem>\n{problem.strip()}\n</problem>\n"
        f"<user_stated_field_label_only>{source_field.strip() or 'not given'}</user_stated_field_label_only>\n"
        f"<user_constraints>{constraints.strip() or 'none given'}</user_constraints>"
    )
    out = call_json(AbstractionOut, SYSTEM, user, settings, client=client, max_tokens=3500)
    return Abstraction(**out.model_dump())
