"""The four Bio-Bridge agents: abstractor, explorer, critic, translator."""
