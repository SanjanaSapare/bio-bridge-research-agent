"""Agent 3: skeptically test whether each paper's mechanism genuinely transfers.

The model proposes; Python verifies. Every statement the model attributes to a paper must carry a
verbatim quote that is found in the retrieved abstract, otherwise it is dropped. The final score,
evidence caps and label consistency are computed in Python (see scoring.py), not taken on trust."""
from __future__ import annotations

from config import Settings
from integrity import verify_quote
from llm import LLMError, LLMOutputError, call_json
from schemas import Abstraction, CriticOut, Evaluation, Paper, SourceClaim
from scoring import LABEL_RANK, apply_evidence_caps, guard_label, weighted_score

MAX_CANDIDATES = 3

SYSTEM = """You are the Critic in a cross-disciplinary research tool. Be skeptical, not enthusiastic.
You get a decomposed target problem and ONE paper (title + abstract only). Judge whether the paper's
actual mechanism, objective and operating conditions fit the problem. Never judge by shared vocabulary.

Part A: what the PAPER reports (only if the abstract states it; otherwise leave empty/null).
- paper_objective, paper_method, reported_findings, reported_limitations: each item is
  {statement, quote}. `quote` MUST be copied word-for-word from the abstract (a short passage; "..." may
  join two passages). Never paraphrase inside `quote`. Software checks every quote; invalid ones are
  discarded. Do not add findings or limitations the abstract does not state.
Part B: YOUR interpretation (clearly yours, not the paper's).
- mechanism_extracted: the specific mechanism in this paper that might be reusable.
- shared_structure: what structure the paper and the problem truly share; say so if little.
- mappings: problem concept <-> paper concept pairs.
- what_transfers / needs_modification: what could be reused as is, and what must change and why.
- differences: ways the paper's setting differs from the problem (objective, scale, constraints,
  timescale, noise, information, feedback). Prefer naming incompatibilities over forcing the analogy.
- assumptions: what must hold for the transfer to work. risks: {risk, mitigation}.
Scores, each 0-10 and independent:
- objective_alignment: comparable goal? mechanism_alignment: same underlying mechanism?
- constraint_compatibility: workable under the problem's constraints?
- evidence_strength: how well the ABSTRACT supports the paper's own claims (tested results high; a
  proposal or conceptual argument low). It is NOT how well the paper fits the problem.
- adaptation_feasibility: how easy the adaptation would be (10 = trivial, 0 = impractical).
Use the full range; most papers deserve 2-6 on most criteria. score_rationale: why these scores.
main_uncertainty: the single biggest reason this could be wrong.
label: "promising" (strong fit as is), "promising_with_modifications" (real fit but needs identified
changes), "speculative" (plausible idea, weak support), "poorly_supported" (no real transfer).
Only the abstract is available; never imply you read the full paper. Return JSON only."""


def _prompt(abstraction: Abstraction, paper: Paper) -> str:
    return (
        "<problem>\n"
        f"Objective: {abstraction.objective}\n"
        f"Domain-independent description: {abstraction.abstract_description}\n"
        f"Mechanisms involved: {'; '.join(abstraction.mechanisms) or 'not stated'}\n"
        f"Variables: {'; '.join(abstraction.variables) or 'not stated'}\n"
        f"Constraints: {'; '.join(abstraction.constraints) or 'none stated'}\n"
        "</problem>\n"
        f'<paper id="{paper.paper_id}" field="{paper.target_field}">\n'
        f"Title: {paper.title}\n"
        f"Abstract: {paper.abstract}\n"
        "</paper>"
    )


def _keep_verified(claims: list[SourceClaim], text: str) -> list[SourceClaim]:
    return [c for c in claims if verify_quote(c.quote, text)]


def build_evaluation(out: CriticOut, paper: Paper) -> Evaluation:
    """Verify claims against the retrieved abstract, then score and label in Python."""
    text = f"{paper.title}. {paper.abstract}"
    claimed = [c for c in (out.paper_objective, out.paper_method) if c] + out.reported_findings + out.reported_limitations
    objective = out.paper_objective if out.paper_objective and verify_quote(out.paper_objective.quote, text) else None
    method = out.paper_method if out.paper_method and verify_quote(out.paper_method.quote, text) else None
    findings = _keep_verified(out.reported_findings, text)
    limits = _keep_verified(out.reported_limitations, text)
    kept = sum(1 for c in (objective, method) if c) + len(findings) + len(limits)

    scores, notes = apply_evidence_caps(out.scores.model_dump(), len(findings))
    score = weighted_score(scores)
    label, label_notes = guard_label(out.label, score, scores, kept)

    if not claimed:
        vnote = "The model reported no claims from the paper, so nothing could be verified."
    else:
        vnote = (f"{kept} of {len(claimed)} statements attributed to the paper were matched word-for-word "
                 f"to its abstract; {len(claimed) - kept} were removed because the quoted text was not found.")

    data = out.model_dump()
    data.update(
        paper_objective=objective.model_dump() if objective else None,
        paper_method=method.model_dump() if method else None,
        reported_findings=[c.model_dump() for c in findings],
        reported_limitations=[c.model_dump() for c in limits],
        scores=scores,
        label=label,
    )
    return Evaluation(**data, paper_id=paper.paper_id, transferability_score=score,
                      score_reliable=kept > 0, score_notes=notes + label_notes, verification_note=vnote)


def sort_key(e: Evaluation) -> tuple:
    return (e.transferability_score, LABEL_RANK[e.label], e.scores.mechanism_alignment)


def select_candidates(evals: list[Evaluation], n: int = MAX_CANDIDATES) -> list[Evaluation]:
    """Up to n connections worth carrying forward: everything not 'poorly_supported', best first.
    Fewer than n (even none) is a valid answer; nothing is added to fill space."""
    cands = [e for e in evals if e.label != "poorly_supported"]
    cands.sort(key=sort_key, reverse=True)
    return cands[:n]


def critique(
    abstraction: Abstraction, shortlist: list[Paper], settings: Settings, client=None
) -> tuple[list[Evaluation], list[str]]:
    evals: list[Evaluation] = []
    warns: list[str] = []
    if not shortlist:
        return evals, ["No papers were available for the Critic to evaluate."]
    last_error: LLMError | None = None
    for i, paper in enumerate(shortlist):  # one at a time on purpose: free-tier limits are per minute
        try:
            out = call_json(CriticOut, SYSTEM, _prompt(abstraction, paper), settings,
                            client=client, max_tokens=3000)
        except LLMOutputError as exc:  # this paper's reply was unusable; other papers may still work
            last_error = exc
            warns.append(f"Skipped '{paper.title[:70]}': the model's evaluation was not valid ({str(exc)[:120]}).")
            continue
        except LLMError as exc:  # quota, key, network: the next call would fail too
            last_error = exc
            if not evals:
                raise
            warns.append(f"Stopped after {len(evals)} of {len(shortlist)} papers: {exc}")
            break
        evals.append(build_evaluation(out, paper))
    if not evals and last_error is not None:
        raise last_error
    evals.sort(key=sort_key, reverse=True)
    return evals, warns
