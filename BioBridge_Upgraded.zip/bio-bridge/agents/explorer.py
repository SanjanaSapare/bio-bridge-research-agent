"""Agent 2: search real papers (arXiv + optional Semantic Scholar), rank them locally.

Retrieval relevance (embedding similarity) is used ONLY to choose which papers the Critic reads."""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Optional

from config import Settings
from schemas import Abstraction, Paper
from scoring import cosine, normalize_similarity
from sources import SourceError, arxiv_src, s2_src

ARXIV_DELAY = 3.0  # seconds between arXiv requests, as arXiv asks
S2_DELAY = 1.1     # unauthenticated Semantic Scholar allows about 1 request per second
MIN_ABSTRACT_CHARS = 50
MAX_STORED_ABSTRACT = 4000  # abstracts are kept whole (quote checks need the full text); only absurd ones are cut


class ResearchRetrievalError(RuntimeError):
    """No usable papers could be retrieved."""


def _default_embed(settings: Settings) -> Callable[[list[str]], list[list[float]]]:
    from fastembed import TextEmbedding  # lazy: first use downloads a small model

    model = TextEmbedding(model_name=settings.embed_model)
    return lambda texts: [[float(x) for x in v] for v in model.embed(texts)]


def _norm_title(t: str) -> str:
    return "".join(ch for ch in t.lower() if ch.isalnum())


def _merge_missing(keep: Paper, other: Paper) -> None:
    """Fill empty metadata on `keep` from a duplicate record of the same paper. Never overwrites."""
    if not keep.authors and other.authors:
        keep.authors = other.authors
    if not keep.doi and other.doi:
        keep.doi = other.doi
    if not keep.arxiv_id and other.arxiv_id:
        keep.arxiv_id = other.arxiv_id
    if keep.year is None and other.year is not None:
        keep.year = other.year


def _interleave(papers: list[Paper]) -> list[Paper]:
    """Round-robin across target fields so no single field dominates when similarity is unavailable."""
    buckets: dict[str, list[Paper]] = {}
    for p in papers:
        buckets.setdefault(p.target_field, []).append(p)
    out: list[Paper] = []
    while any(buckets.values()):
        for b in buckets.values():
            if b:
                out.append(b.pop(0))
    return out


def _pick_shortlist(ranked: list[Paper], limit: int, per_field: int = 2) -> list[Paper]:
    picked: list[Paper] = []
    counts: dict[str, int] = {}
    for p in ranked:
        if len(picked) >= limit:
            break
        if counts.get(p.target_field, 0) < per_field:
            picked.append(p)
            counts[p.target_field] = counts.get(p.target_field, 0) + 1
    for p in ranked:  # top up if the per-field cap left gaps
        if len(picked) >= limit:
            break
        if p not in picked:
            picked.append(p)
    return picked


def explore(
    abstraction: Abstraction,
    settings: Settings,
    embed: Optional[Callable] = None,
    http_get: Optional[Callable] = None,
) -> tuple[list[Paper], list[Paper], list[str]]:
    """Return (shortlist, ranked, warnings). Raises ResearchRetrievalError if nothing usable is found."""
    queries = abstraction.bridge_queries
    errors: list[str] = []

    def run_arxiv() -> list[Paper]:
        found: list[Paper] = []
        for i, q in enumerate(queries):
            if i:
                time.sleep(ARXIV_DELAY)
            try:
                found += arxiv_src.search_arxiv(
                    q.keywords, q.search_query, q.target_field,
                    settings.max_papers_per_search, settings.request_timeout, http_get,
                )
            except SourceError as exc:
                errors.append(f"arXiv ({q.target_field}): {exc}")
        return found

    def run_s2() -> list[Paper]:
        found: list[Paper] = []
        for i, q in enumerate(queries):
            if i:
                time.sleep(S2_DELAY)
            try:
                found += s2_src.search_s2(
                    q.search_query, q.target_field, settings.max_papers_per_search,
                    settings.request_timeout, settings.s2_api_key, http_get,
                )
            except s2_src.RateLimited as exc:
                errors.append(f"Semantic Scholar: {exc}. Continuing without it.")
                break  # more requests would only be refused too
            except SourceError as exc:
                errors.append(f"Semantic Scholar ({q.target_field}): {exc}")
        return found

    with ThreadPoolExecutor(max_workers=2) as pool:
        fa, fs = pool.submit(run_arxiv), pool.submit(run_s2)
        arxiv_papers, s2_papers = fa.result(), fs.result()

    # de-duplicate (same id or same normalised title); the first record wins but gaps in it are filled
    # from the duplicate, so e.g. a DOI known only to Semantic Scholar is not lost
    by_id: dict[str, Paper] = {}
    by_title: dict[str, Paper] = {}
    papers: list[Paper] = []
    for p in arxiv_papers + s2_papers:
        if len(p.abstract) < MIN_ABSTRACT_CHARS:
            continue
        nt = _norm_title(p.title)
        first = by_id.get(p.paper_id) or by_title.get(nt)
        if first is not None:
            _merge_missing(first, p)
            continue
        if len(p.abstract) > MAX_STORED_ABSTRACT:
            p.abstract = p.abstract[:MAX_STORED_ABSTRACT].rsplit(" ", 1)[0] + " ..."
        by_id[p.paper_id] = by_title[nt] = p
        papers.append(p)

    warns = list(dict.fromkeys(errors))  # unique, in order
    if not papers:
        detail = warns[0] if warns else "The searches returned no papers with usable abstracts."
        raise ResearchRetrievalError(f"Could not retrieve research papers. {detail}")

    # local semantic ranking
    try:
        embed_fn = embed or _default_embed(settings)
        qtext = " ".join(
            x for x in [abstraction.objective, abstraction.abstract_description,
                        "Mechanisms: " + "; ".join(abstraction.mechanisms),
                        "Structure: " + "; ".join(abstraction.math_primitives)] if x.strip())
        vecs = embed_fn([qtext] + [f"{p.title}. {p.abstract}" for p in papers])
        if len(vecs) != len(papers) + 1:
            raise ValueError("embedding count mismatch")
        raws = [cosine(vecs[0], v) for v in vecs[1:]]
        for p, raw in zip(papers, raws):
            p.similarity_raw = round(raw, 4)
            p.similarity_norm = round(normalize_similarity(raw), 4)
        papers.sort(key=lambda p: p.similarity_raw or 0.0, reverse=True)
    except Exception as exc:
        warns.append(
            f"Retrieval ranking by embedding similarity could not be computed ({type(exc).__name__}: {str(exc)[:120]}). "
            "Papers are kept in search order; the Critic still evaluates them normally."
        )
        papers = _interleave(papers)

    ranked = papers[: settings.rerank_limit]
    shortlist = _pick_shortlist(ranked, settings.shortlist_limit)
    return shortlist, ranked, warns
