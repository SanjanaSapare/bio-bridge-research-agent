"""Agent 4: turn the supported connections into a testable proposal with Python-verified references."""
from __future__ import annotations

from config import Settings
from integrity import allowed_from_papers, scrub_obj
from llm import call_json
from schemas import LABEL_TEXT, Abstraction, Evaluation, Paper, Proposal, ProposalOut, Reference

EVIDENCE_BASIS = (
    "Evidence basis: this proposal was written from retrieved titles and abstracts only; no full paper "
    "was read. Statements attributed to a paper were kept only if the quoted words were found in its "
    "abstract, and every reference below was matched to a retrieved record. Whether those papers' "
    "findings are correct, and whether the mechanism transfers, has not been independently verified. "
    "Everything in 'Adaptation' and 'Validation plan' is AI-generated interpretation to be tested."
)

SYSTEM = """You are the Translator in a cross-disciplinary research tool. Write a concrete, falsifiable
research proposal from the supplied candidate connections. Candidate 1 is the primary connection; use
others only where they add something and say how they differ.
Rules:
- Use ONLY the supplied papers. Cite them in prose as [paper_id] and list the ids in cited_paper_ids.
  Never invent papers, authors, results, numbers, DOIs or links.
- Attribute a finding to a paper ONLY if it appears under "Reported by the paper". Everything else is your
  proposal or an assumption and must be worded as such ("we hypothesise", "if ... holds").
- Respect each candidate's label. If the primary connection is "speculative", frame the proposal as an
  exploratory test of whether the mechanism transfers, not as a solution. Never say a paper proves
  the transfer; at most it supports part of the analogy.
- adaptation: reuse (what can be taken as is), modify (what must change and why), how_it_addresses_problem.
- validation_plan: baseline (the current or standard method to beat), metrics, required_data, and
  failure_conditions (results that would show the idea does NOT work).
- hypothesis: one falsifiable statement. experiments: at most 3, each with baselines and metrics.
- risks and limitations_and_assumptions must reflect the Critic's differences and risks.
- evidence_statement: 1-3 sentences saying plainly what evidence supports this and what does not.
Return JSON only."""


def _claims(items) -> str:
    return " | ".join(c.statement for c in items) or "none verified"


def _prompt(problem: str, abstraction: Abstraction, top: list[Evaluation], by_id: dict[str, Paper]) -> tuple[str, list[Paper]]:
    used: list[Paper] = []
    blocks: list[str] = []
    for n, e in enumerate(top, 1):
        p = by_id.get(e.paper_id)
        if p is None:
            continue
        used.append(p)
        reported = (
            f"objective: {e.paper_objective.statement if e.paper_objective else 'not verified'}; "
            f"method: {e.paper_method.statement if e.paper_method else 'not verified'}; "
            f"findings: {_claims(e.reported_findings)}; limitations: {_claims(e.reported_limitations)}"
        )
        blocks.append(
            f'<paper id="{p.paper_id}" candidate="{n}">\nTitle: {p.title}\nYear: {p.year or "unavailable"}\n'
            f"Field: {p.target_field}\nAbstract: {p.abstract}\n"
            f"Reported by the paper (verified against the abstract): {reported}\n"
            f"Critic (AI interpretation): label {LABEL_TEXT[e.label]}, score {e.transferability_score}/10, "
            f"main uncertainty: {e.main_uncertainty}\n"
            f"Mechanism: {e.mechanism_extracted}\nShared structure: {e.shared_structure}\n"
            f"Transfers: {' | '.join(e.what_transfers) or 'n/a'}\n"
            f"Needs modification: {' | '.join(e.needs_modification) or 'n/a'}\n"
            f"Differences: {' | '.join(e.differences) or 'n/a'}\n"
            f"Risks: {' | '.join(r.risk for r in e.risks) or 'n/a'}\n</paper>"
        )
    prompt = (
        f"<problem>\n{problem.strip()}\n</problem>\n"
        f"Objective: {abstraction.objective}\n"
        f"Domain-independent description: {abstraction.abstract_description}\n"
        f"Constraints: {'; '.join(abstraction.constraints) or 'none stated'}\n"
        f"Variables: {'; '.join(abstraction.variables) or 'not stated'}\n\n"
        + "\n".join(blocks)
        + "\n\nAllowed paper ids: " + ", ".join(p.paper_id for p in used)
    )
    return prompt, used


def translate(
    problem: str,
    abstraction: Abstraction,
    top: list[Evaluation],
    by_id: dict[str, Paper],
    settings: Settings,
    client=None,
) -> Proposal:
    prompt, used = _prompt(problem, abstraction, top, by_id)
    out = call_json(ProposalOut, SYSTEM, prompt, settings, client=client, max_tokens=6000, temperature=0.3)
    ids, dois, urls = allowed_from_papers(used)

    dropped: list[str] = []
    cited: list[str] = []
    for cid in out.cited_paper_ids:
        cid = cid.strip()
        if cid in ids:
            if cid not in cited:
                cited.append(cid)
        elif cid and cid not in dropped:
            dropped.append(cid)
    if not cited:  # the model cited nothing valid: fall back to the papers it was actually given
        cited = [p.paper_id for p in used]

    data = scrub_obj(out.model_dump(), ids, dois, urls, dropped)
    data["cited_paper_ids"] = cited
    by_used = {p.paper_id: p for p in used}
    refs = [  # built from retrieved records only, never from model text
        Reference(paper_id=i, title=by_used[i].title, year=by_used[i].year, url=by_used[i].url,
                  source=by_used[i].source, authors=by_used[i].authors, doi=by_used[i].doi,
                  arxiv_id=by_used[i].arxiv_id)
        for i in cited
    ]
    return Proposal(**data, references=refs, dropped_citations=dropped, evidence_basis=EVIDENCE_BASIS)


def reference_line(r: Reference) -> str:
    authors = ", ".join(r.authors[:4]) + (" et al." if len(r.authors) > 4 else "") if r.authors else "Authors unavailable"
    ids = [f"arXiv:{r.arxiv_id}"] if r.arxiv_id else []
    if r.doi:
        ids.append(f"DOI:{r.doi}")
    return (f"[{r.paper_id}] {authors}. {r.title} ({r.year or 'year unavailable'}). {r.source}. "
            + (" ".join(ids) + ". " if ids else "") + r.url)


def proposal_to_markdown(pr: Proposal, problem: str, abstraction: Abstraction) -> str:
    def bullets(items: list[str]) -> str:
        return "\n".join(f"- {x}" for x in items) or "- none stated"

    lines = [
        f"# {pr.title}", "",
        "> Generated by Bio-Bridge. A research-planning aid, not peer reviewed.", "",
        f"> {pr.evidence_basis or 'Based on retrieved abstracts only.'}", "",
        "## Executive summary", pr.executive_summary, "",
        "## Problem understanding", f"**Original problem.** {problem.strip()}", "",
        f"**Objective.** {abstraction.objective or 'not extracted'}", "",
        f"**Constraints.**\n{bullets(abstraction.constraints)}", "",
        f"**Underlying structure.** {pr.problem_and_structure}", "",
        "## Selected mechanism (AI interpretation of the cited papers)", pr.selected_mechanism, "",
        "## Evidence statement", pr.evidence_statement or "Not provided.", "",
        "## Hypothesis", pr.hypothesis, "",
    ]
    if pr.adaptation:
        a = pr.adaptation
        lines += ["## Proposed adaptation", "**Reuse**", bullets(a.reuse), "", "**Modify**", bullets(a.modify), "",
                  a.how_it_addresses_problem, ""]
    lines += ["## Methodology", "\n".join(f"{i}. {m}" for i, m in enumerate(pr.methodology, 1)) or "- none", ""]
    if pr.variables_and_updates:
        lines += ["## Variables and update rules", pr.variables_and_updates, ""]
    if pr.validation_plan:
        v = pr.validation_plan
        lines += ["## Validation plan", f"**Baseline.** {v.baseline}", "", "**Metrics**", bullets(v.metrics), "",
                  "**Required data**", bullets(v.required_data), "",
                  "**Failure conditions (result that would refute the idea)**", bullets(v.failure_conditions), ""]
    if pr.experiments:
        lines += ["## Experiments"]
        for ex in pr.experiments:
            lines += [f"### {ex.name}", ex.description, ""]
            if ex.baselines:
                lines += ["Baselines:", bullets(ex.baselines), ""]
            if ex.metrics:
                lines += ["Metrics:", bullets(ex.metrics), ""]
    lines += [
        "## Expected outcomes (hypothesised)", bullets(pr.expected_outcomes), "",
        "## Risks", bullets(pr.risks), "",
        "## Limitations and assumptions", bullets(pr.limitations_and_assumptions), "",
        "## References (retrieved records; abstracts only)",
    ]
    lines += [f"- {reference_line(r)}" for r in pr.references]
    return "\n".join(lines).strip() + "\n"
