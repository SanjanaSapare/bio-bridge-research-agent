"""Sequential four-agent pipeline with real status reporting."""
from __future__ import annotations

from typing import Callable, Optional

import cache
from agents import abstractor, critic, explorer, translator
from agents.critic import select_candidates
from config import Settings
from llm import LLMError
from schemas import AgentStatus, RunResult

AGENT_NAMES = ["Abstractor", "Explorer", "Critic", "Translator"]

# (agent_index, state, message) -> None
StatusCallback = Callable[[int, str, str], None]


def run_pipeline(
    problem: str,
    source_field: str,
    constraints: str,
    settings: Settings,
    on_status: Optional[StatusCallback] = None,
    client=None,
    embed=None,
    http_get=None,
    use_cache: bool = True,
) -> RunResult:
    """Run all four agents in order. Never raises for expected failures: the failing agent is
    marked 'failed', `result.error` explains why, and everything finished so far is kept."""
    result = RunResult(
        problem=problem,
        source_field_input=source_field,
        constraints_input=constraints,
        agents=[AgentStatus(name=n) for n in AGENT_NAMES],
    )

    def status(i: int, state: str, msg: str = "") -> None:
        result.agents[i].state = state  # type: ignore[assignment]
        result.agents[i].message = msg
        if on_status:
            on_status(i, state, msg)

    key = cache.cache_key(problem, source_field, constraints, settings.model)
    if use_cache:
        cached = cache.load_run(key)
        if cached is not None and cached.proposal is not None:
            cached.warnings = ["Loaded from your local cache of an earlier live run."] + cached.warnings
            for i in range(4):
                status(i, "completed", "Loaded from cache")
            return cached

    current = 0
    try:
        # ---- Agent 1
        current = 0
        status(0, "running", "Decomposing the problem: objective, constraints, variables, mechanisms...")
        result.abstraction = abstractor.abstract_problem(
            problem, source_field, constraints, settings, client=client
        )
        status(0, "completed", f"{len(result.abstraction.bridge_queries)} research directions planned")

        # ---- Agent 2
        current = 1
        status(1, "running", "Searching arXiv and Semantic Scholar...")
        shortlist, ranked, warns = explorer.explore(
            result.abstraction, settings, embed=embed, http_get=http_get
        )
        result.papers = ranked
        result.warnings.extend(warns)
        status(1, "completed", f"{len(ranked)} papers retrieved, {len(shortlist)} sent to the Critic")

        # ---- Agent 3
        current = 2
        status(2, "running", f"Testing whether the mechanisms transfer ({len(shortlist)} papers)...")
        evals, warns = critic.critique(result.abstraction, shortlist, settings, client=client)
        result.evaluations = evals
        result.warnings.extend(warns)
        top = select_candidates(evals)
        result.candidate_ids = [e.paper_id for e in top]
        status(2, "completed", f"{len(evals)} evaluated, {len(top)} supported connection(s)")

        # ---- Agent 4
        current = 3
        if not top:
            result.insufficient_reason = (
                "The retrieved research did not support a transferable connection: every evaluated paper was "
                "judged poorly supported. Bio-Bridge does not invent a match. Try describing the objective and "
                "constraints in more detail, or run it again to search different directions."
            )
            status(3, "completed", "No supported connection; proposal not written")
        else:
            status(3, "running", f"Writing a proposal from {len(top)} connection(s)...")
            by_id = {p.paper_id: p for p in ranked}
            result.proposal = translator.translate(
                problem, result.abstraction, top, by_id, settings, client=client
            )
            if result.proposal.dropped_citations:
                result.warnings.append(
                    "Unverified citations or links removed from the proposal: "
                    + ", ".join(result.proposal.dropped_citations)
                )
            status(3, "completed", "Proposal ready")
            if use_cache:
                cache.save_run(result, key)
    except explorer.ResearchRetrievalError as exc:
        result.error = (
            f"{exc} Check your internet connection and try again, or load a cached "
            "demonstration from the sidebar."
        )
        status(current, "failed", "Research retrieval failed")
    except LLMError as exc:
        result.error = f"{exc} You can retry, or load a cached demonstration from the sidebar."
        status(current, "failed", str(exc)[:200])
    except Exception as exc:  # last-resort guard so the UI never crashes
        result.error = (
            f"Unexpected error in {AGENT_NAMES[current]}: {type(exc).__name__}: {str(exc)[:200]}"
        )
        status(current, "failed", result.error)
    return result
