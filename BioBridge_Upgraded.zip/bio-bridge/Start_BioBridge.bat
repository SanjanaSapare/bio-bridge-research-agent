@echo off
setlocal EnableExtensions
title Bio-Bridge launcher
cd /d "%~dp0"

set "APP_FILE=app.py"
set "VENV_DIR=.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"
set "STAMP=%VENV_DIR%\requirements.installed.txt"
set "PORT=8501"
set "URL=http://localhost:%PORT%"
set "RETRIED=0"

echo.
echo ================================================
echo   Bio-Bridge - cross-disciplinary research tool
echo ================================================
echo.

rem ---- 0. sanity check: are we in the project folder?
if not exist "%APP_FILE%" (
    echo [ERROR] Cannot find %APP_FILE% in this folder:
    echo         %CD%
    echo         Extract the WHOLE zip file first, then run this launcher from the extracted folder.
    echo         It must stay next to app.py and requirements.txt.
    goto :fail
)
if not exist "requirements.txt" (
    echo [ERROR] requirements.txt is missing from %CD%
    echo         Extract the WHOLE zip file again.
    goto :fail
)

rem ---- already running? Open it instead of starting a second copy.
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>&1
if not errorlevel 1 (
    echo Bio-Bridge seems to be running already on port %PORT%.
    echo Opening it in your browser instead of starting a second copy.
    start "" "%URL%"
    echo.
    echo If the page does not load, another program may be using port %PORT%.
    echo Close that program or restart your computer, then run this launcher again.
    timeout /t 6 >nul
    exit /b 0
)

rem ---- 1. private Python environment
if exist "%VENV_PY%" (
    "%VENV_PY%" -c "import sys" >nul 2>&1
    if errorlevel 1 (
        echo The saved Python environment is broken, so it will be rebuilt.
        rmdir /s /q "%VENV_DIR%"
    )
)
if exist "%VENV_PY%" (
    echo [1/4] Python environment found.
    goto :deps
)

set "PY="
for %%V in (3.13 3.12 3.11 3.10) do (
    if not defined PY (
        py -%%V -c "import sys" >nul 2>&1
        if not errorlevel 1 set "PY=py -%%V"
    )
)
if not defined PY (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
    if not errorlevel 1 set "PY=python"
)
if not defined PY (
    echo [ERROR] Python 3.10 or newer was not found on this computer.
    echo.
    echo   1. Download Python 3.12 or 3.13 from https://www.python.org/downloads/
    echo   2. Run the installer and TICK the box "Add python.exe to PATH".
    echo   3. Then double-click Start_BioBridge.bat again.
    echo.
    echo   Note: the "python" shortcut that opens the Microsoft Store does not count.
    goto :fail
)
echo [1/4] Creating the private Python environment. This happens only once...
%PY% -m venv "%VENV_DIR%"
if errorlevel 1 (
    echo [ERROR] Could not create the Python environment.
    echo         Check that you have free disk space and that the folder is not read-only.
    goto :fail
)
if not exist "%VENV_PY%" (
    echo [ERROR] The environment was created but python.exe is missing inside it.
    goto :fail
)

rem ---- 2. packages (skipped when requirements.txt has not changed)
:deps
set "NEED_INSTALL=1"
if exist "%STAMP%" (
    fc /b "requirements.txt" "%STAMP%" >nul 2>&1
    if not errorlevel 1 set "NEED_INSTALL=0"
)
if "%NEED_INSTALL%"=="1" (
    echo [2/4] Installing the required packages. The first time can take a few minutes...
    "%VENV_PY%" -m pip install --disable-pip-version-check -r requirements.txt
    if errorlevel 1 (
        echo.
        echo [ERROR] Package installation failed. Read the lines above.
        echo         Most common causes: no internet connection, a VPN or proxy blocking pypi.org,
        echo         or a very new Python version without ready-made packages.
        echo         Fix: connect to the internet and run this launcher again. If it still fails,
        echo         install Python 3.12 or 3.13, delete the .venv folder, and try again.
        goto :fail
    )
    copy /y "requirements.txt" "%STAMP%" >nul
) else (
    echo [2/4] Packages already installed. Skipping.
)
"%VENV_PY%" -c "import streamlit, pydantic, requests, numpy, dotenv, google.genai" >nul 2>&1
if errorlevel 1 (
    if "%RETRIED%"=="1" (
        echo [ERROR] The packages are installed but cannot be loaded.
        echo         Delete the .venv folder and run this launcher again.
        goto :fail
    )
    echo Some packages are missing, reinstalling them once...
    set "RETRIED=1"
    del /q "%STAMP%" >nul 2>&1
    goto :deps
)

rem ---- 3. settings file (.env) with the Gemini key
if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo.
        echo [3/4] First-time setup: I created your settings file named .env
        echo.
        echo   Notepad will open next. Do this:
        echo     a. Get a FREE key at https://aistudio.google.com/apikey
        echo     b. In Notepad, replace your_key_here with your key after GEMINI_API_KEY=
        echo     c. Save the file and close Notepad.
        echo.
        pause
        start "" /wait notepad ".env"
    ) else (
        echo [WARNING] .env.example is missing, so no settings file was created.
        echo           Create a text file named .env containing the two lines GEMINI_API_KEY and MODEL.
    )
)
"%VENV_PY%" -c "import sys; from config import load_settings; p = load_settings().problems(); print(chr(10).join('   - ' + x for x in p)); sys.exit(1 if p else 0)"
if errorlevel 1 (
    echo.
    echo [NOTE] Live mode is not configured yet, see the points above.
    echo        Bio-Bridge will still open. The Settings page explains what to do.
    echo        To fix it: open the .env file with Notepad, add your key, save,
    echo        then close Bio-Bridge and start it again.
    echo.
) else (
    echo [3/4] Settings found. Your key is never shown on screen.
)

rem ---- Streamlit asks for an email on its very first run unless this file exists.
set "ST_DIR=%USERPROFILE%\.streamlit"
if not exist "%ST_DIR%\credentials.toml" (
    if not exist "%ST_DIR%" mkdir "%ST_DIR%"
    > "%ST_DIR%\credentials.toml" echo [general]
    >> "%ST_DIR%\credentials.toml" echo email = ""
)

rem ---- 4. start the app
echo [4/4] Starting Bio-Bridge...
echo.
echo   Your browser will open at %URL%
echo   If it does not, open that address yourself.
echo   TO STOP: press Ctrl+C in this window, or simply close this window.
echo   If asked "Terminate batch job", type Y and press Enter.
echo.
"%VENV_PY%" -m streamlit run "%APP_FILE%" --server.port %PORT% --server.address localhost --server.headless false --browser.gatherUsageStats false
set "EXITCODE=%ERRORLEVEL%"
echo.
if not "%EXITCODE%"=="0" (
    echo [ERROR] Bio-Bridge stopped unexpectedly, code %EXITCODE%. Read the messages above.
    goto :fail
)
echo Bio-Bridge has stopped. You can close this window.
timeout /t 3 >nul
exit /b 0

:fail
echo.
echo ------------------------------------------------
echo   Something went wrong. Nothing on your computer was damaged.
echo   Open README_START_HERE.txt and look under TROUBLESHOOTING.
echo ------------------------------------------------
echo.
pause
exit /b 1
