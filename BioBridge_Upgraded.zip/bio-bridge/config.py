"""Central configuration. Reads settings from the environment (.env locally,
Streamlit secrets when deployed). No secrets live in source code."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
EXAMPLES_DIR = BASE_DIR / "data" / "examples"
CACHE_DIR = BASE_DIR / "data" / "cache"

load_dotenv(BASE_DIR / ".env")

PLACEHOLDER_KEYS = {"", "your_key_here", "your_api_key_here"}
PLACEHOLDER_MODELS = {"", "your_free_tier_gemini_model"}


class ConfigError(RuntimeError):
    """Raised when required configuration is missing."""


def _streamlit_secret(name: str) -> str:
    """Read a Streamlit Community Cloud secret if running under Streamlit."""
    try:
        import streamlit as st  # local import: not needed for tests

        return str(st.secrets.get(name, "") or "")
    except Exception:
        return ""


def _get(name: str, default: str = "") -> str:
    return os.environ.get(name) or _streamlit_secret(name) or default


@dataclass(frozen=True)
class Settings:
    gemini_api_key: str
    model: str
    s2_api_key: str
    max_papers_per_search: int = 8
    rerank_limit: int = 15
    shortlist_limit: int = 5
    request_timeout: int = 20
    llm_timeout: int = 90
    llm_max_retries: int = 3
    llm_concurrency: int = 1  # keep low: free-tier limits are per minute
    embed_model: str = "BAAI/bge-small-en-v1.5"

    def problems(self) -> list[str]:
        """Human-readable list of configuration problems (empty if OK)."""
        out = []
        if self.gemini_api_key in PLACEHOLDER_KEYS:
            out.append("GEMINI_API_KEY is missing. Add it to your .env file.")
        if self.model in PLACEHOLDER_MODELS:
            out.append("MODEL is missing. Set it in .env to a Gemini model ID that your free tier can use.")
        return out

    def validate(self) -> None:
        probs = self.problems()
        if probs:
            raise ConfigError(" ".join(probs))


def _int(name: str, default: int) -> int:
    try:
        return int(_get(name, str(default)))
    except ValueError:
        return default


def load_settings() -> Settings:
    return Settings(
        gemini_api_key=_get("GEMINI_API_KEY").strip(),
        model=_get("MODEL").strip(),
        s2_api_key=_get("S2_API_KEY").strip(),
        max_papers_per_search=_int("MAX_PAPERS_PER_SEARCH", 8),
        rerank_limit=_int("RERANK_LIMIT", 15),
        shortlist_limit=_int("SHORTLIST_LIMIT", 5),
        request_timeout=_int("REQUEST_TIMEOUT", 20),
        llm_concurrency=max(1, _int("LLM_CONCURRENCY", 1)),
    )
