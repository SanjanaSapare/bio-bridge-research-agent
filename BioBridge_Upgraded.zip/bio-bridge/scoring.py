"""Scoring helpers.

Two completely separate things live here and must never be mixed up:

* RETRIEVAL RELEVANCE: cosine similarity between local embeddings of the problem and a paper
  abstract. It only decides which papers are worth sending to the Critic. It says nothing about
  whether a mechanism transfers or whether a paper's claims are true.
* TRANSFERABILITY SCORE: a weighted blend of five criteria judged by the Critic (0-10 each), then
  limited by Python rules (evidence caps, label consistency). It is an ordinal ranking aid for
  comparing candidates, NOT a probability that the idea will work. Similarity is not an input.
"""
from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------- retrieval relevance (ranking only)
SIM_LOW = 0.35   # cosine at or below this -> normalised 0.0
SIM_HIGH = 0.80  # cosine at or above this -> normalised 1.0


def cosine(a, b) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    if denom == 0:
        return 0.0
    return float(np.dot(a, b) / denom)


def normalize_similarity(cos: float) -> float:
    return float(min(1.0, max(0.0, (cos - SIM_LOW) / (SIM_HIGH - SIM_LOW))))


# ---------------------------------------------------------------- transferability score
WEIGHTS = {
    "objective_alignment": 0.20,
    "mechanism_alignment": 0.30,
    "constraint_compatibility": 0.20,
    "evidence_strength": 0.15,
    "adaptation_feasibility": 0.15,
}
CRITERIA_TEXT = {
    "objective_alignment": "Does the paper pursue a goal comparable to the user's objective?",
    "mechanism_alignment": "Is the underlying mechanism structurally the same, not just similar in wording?",
    "constraint_compatibility": "Could the mechanism work under the user's constraints and operating conditions?",
    "evidence_strength": "How well does the retrieved text support the paper's own claims? (abstract only)",
    "adaptation_feasibility": "How much, and how hard, would the adaptation be?",
}
# evidence can never exceed these, whatever the model says
EVIDENCE_CAP_ABSTRACT_ONLY = 7.0   # only abstracts are read, never full papers
EVIDENCE_CAP_NO_VERIFIED_FINDING = 3.0  # no reported finding could be matched to the abstract text

LABEL_RANK = {"poorly_supported": 0, "speculative": 1, "promising_with_modifications": 2, "promising": 3}

EXPLANATION = (
    "Transferability score = 30% mechanism alignment + 20% objective alignment + 20% constraint "
    "compatibility + 15% evidence strength + 15% adaptation feasibility. Each criterion is judged by the "
    "Critic from the paper's abstract only, then Python limits it: evidence strength is capped at 7/10 "
    "because only abstracts are read, and at 3/10 when no reported finding can be matched to the abstract "
    "text. Scores are rounded to the nearest 0.5 because the inputs are not precise enough for more. "
    "It is a ranking aid for comparing candidates, NOT the probability that the idea will work. "
    "Embedding similarity is a separate retrieval signal used only to choose which papers to read; it is "
    "not part of this score and is not evidence of scientific validity."
)


def weighted_score(scores: dict) -> float:
    total = sum(WEIGHTS[k] * float(scores[k]) for k in WEIGHTS)
    return round(min(10.0, max(0.0, total)) * 2) / 2  # nearest 0.5


def apply_evidence_caps(scores: dict, verified_findings: int) -> tuple[dict, list[str]]:
    """Return (possibly lowered scores, notes explaining each change)."""
    out = dict(scores)
    notes: list[str] = []
    cap = EVIDENCE_CAP_ABSTRACT_ONLY
    why = "only the abstract was read"
    if verified_findings == 0:
        cap = EVIDENCE_CAP_NO_VERIFIED_FINDING
        why = "no reported finding could be matched to the abstract text"
    if out["evidence_strength"] > cap:
        notes.append(f"Evidence strength lowered from {out['evidence_strength']:.1f} to {cap:.1f}: {why}.")
        out["evidence_strength"] = cap
    return out, notes


def guard_label(label: str, score: float, scores: dict, verified_total: int) -> tuple[str, list[str]]:
    """Make the label consistent with the numbers. Only ever lowers a label."""
    notes: list[str] = []
    new = label

    def lower(to: str, reason: str) -> None:
        nonlocal new
        if LABEL_RANK[to] < LABEL_RANK[new]:
            notes.append(f"Label lowered from '{new}' to '{to}': {reason}.")
            new = to

    if score < 3.0:
        lower("poorly_supported", "score below 3")
    if score < 5.0:
        lower("speculative", "score below 5")
    if new == "promising":
        if not (score >= 7.5 and scores["mechanism_alignment"] >= 7 and scores["constraint_compatibility"] >= 6
                and scores["evidence_strength"] >= 5):
            lower("promising_with_modifications" if score >= 5.5 else "speculative",
                  "'promising' needs score >= 7.5, mechanism >= 7, constraints >= 6 and evidence >= 5")
    if new == "promising_with_modifications" and not (score >= 5.0 and scores["mechanism_alignment"] >= 5):
        lower("speculative", "needs score >= 5 and mechanism alignment >= 5")
    if verified_total == 0:
        lower("speculative", "nothing the model attributed to the paper could be verified in the abstract")
    return new, notes
