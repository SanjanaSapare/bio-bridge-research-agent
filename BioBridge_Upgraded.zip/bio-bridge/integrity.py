"""Citation and claim integrity helpers (pure Python, no network).

Three jobs:
  1. Normalise identifiers (DOI, arXiv id) and reject malformed ones.
  2. Verify that a "quote" the model attributes to a paper really occurs in the retrieved text.
  3. Remove paper ids, DOIs and links from model-written prose unless they belong to a retrieved paper.
"""
from __future__ import annotations

import re
from typing import Any, Iterable

_DOI_RE = re.compile(r"^10\.\d{4,9}/\S+$")
_ARXIV_NEW = re.compile(r"^\d{4}\.\d{4,5}$")
_ARXIV_OLD = re.compile(r"^[a-z\-]+(\.[A-Za-z]{2})?/\d{7}$")


def clean_doi(value: str | None) -> str:
    """Return a bare DOI like '10.1000/xyz', or '' if the value is not a plausible DOI."""
    v = (value or "").strip()
    v = re.sub(r"^(https?://(dx\.)?doi\.org/|doi:\s*)", "", v, flags=re.I).strip().rstrip(".,;")
    return v if _DOI_RE.match(v) else ""


def clean_arxiv_id(value: str | None) -> str:
    """Return an arXiv id without version/prefix (e.g. '2101.00001'), or '' if malformed."""
    v = (value or "").strip()
    v = re.sub(r"^(arxiv:\s*|https?://arxiv\.org/abs/)", "", v, flags=re.I)
    v = re.sub(r"v\d+$", "", v)
    return v if (_ARXIV_NEW.match(v) or _ARXIV_OLD.match(v)) else ""


# ---------------------------------------------------------------- quote verification
_ELLIPSIS = re.compile(r"\.\.\.|…|\[\s*\.\.\.\s*\]|\[\s*…\s*\]")


def _squash(text: str) -> str:
    """Lower-case and keep letters/digits only, so spacing, hyphenation and punctuation never matter."""
    return re.sub(r"[\W_]+", "", (text or "").lower())


def verify_quote(quote: str, source_text: str, min_chars: int = 12) -> bool:
    """True if every fragment of `quote` (split on ellipses) appears, in order, in `source_text`.

    Meant to catch paraphrased or invented 'quotes'. It cannot judge whether the quote supports
    the claim it is attached to, only that the words are really in the retrieved text."""
    src = _squash(source_text)
    fragments = [_squash(f) for f in _ELLIPSIS.split(quote or "")]
    fragments = [f for f in fragments if f]
    if not fragments or not src:
        return False
    pos = 0
    for frag in fragments:
        if len(frag) < min_chars:
            return False
        idx = src.find(frag, pos)
        if idx < 0:
            return False
        pos = idx + len(frag)
    return True


# ---------------------------------------------------------------- scrubbing model prose
_ID_RE = re.compile(r"\[?\b(arxiv|s2):([A-Za-z0-9/_\-]+(?:\.[A-Za-z0-9/_\-]+)*)\]?", re.I)
_URL_RE = re.compile(r"https?://[^\s\]\)>,;\"']+")
_DOI_IN_TEXT = re.compile(r"\b10\.\d{4,9}/[^\s\]\)>,;\"']+")


def _norm_url(u: str) -> str:
    return u.rstrip("/.").lower()


def allowed_from_papers(papers: Iterable[Any]) -> tuple[set[str], set[str], set[str]]:
    """(paper_ids, lower-cased DOIs, normalised URLs) that model text is allowed to mention."""
    ids: set[str] = set()
    dois: set[str] = set()
    urls: set[str] = set()
    for p in papers:
        ids.add(p.paper_id)
        if p.doi:
            dois.add(p.doi.lower())
            urls.add(_norm_url(f"https://doi.org/{p.doi}"))
        if p.url:
            urls.add(_norm_url(p.url))
    return ids, dois, urls


def scrub_text(text: str, ids: set[str], dois: set[str], urls: set[str], dropped: list[str]) -> str:
    """Replace paper ids, links and DOIs that do not belong to a retrieved paper."""

    def note(item: str) -> None:
        if item not in dropped:
            dropped.append(item)

    def url_repl(m: re.Match) -> str:
        raw = m.group(0)
        trimmed = raw.rstrip(".")
        if _norm_url(trimmed) in urls:
            return raw
        note(trimmed)
        return "[unverified link removed]" + raw[len(trimmed):]

    def id_repl(m: re.Match) -> str:
        prefix, rest = m.group(1).lower(), m.group(2)
        if prefix == "arxiv":
            rest = re.sub(r"v\d+$", "", rest)
        pid = f"{prefix}:{rest}"
        if pid in ids:
            return m.group(0)
        note(pid)
        return "[unverified citation removed]"

    def doi_repl(m: re.Match) -> str:
        raw = m.group(0)
        trimmed = raw.rstrip(".")
        if trimmed.lower() in dois:
            return raw
        note(trimmed)
        return "[unverified DOI removed]" + raw[len(trimmed):]

    # links first, then ids, then bare DOIs; markers inserted by one pass are not matched by the next
    text = _URL_RE.sub(url_repl, text)
    text = _ID_RE.sub(id_repl, text)
    return _DOI_IN_TEXT.sub(doi_repl, text)


def scrub_obj(obj: Any, ids: set[str], dois: set[str], urls: set[str], dropped: list[str]) -> Any:
    """scrub_text applied recursively to strings inside lists and dicts."""
    if isinstance(obj, str):
        return scrub_text(obj, ids, dois, urls, dropped)
    if isinstance(obj, list):
        return [scrub_obj(x, ids, dois, urls, dropped) for x in obj]
    if isinstance(obj, dict):
        return {k: scrub_obj(v, ids, dois, urls, dropped) for k, v in obj.items()}
    return obj
