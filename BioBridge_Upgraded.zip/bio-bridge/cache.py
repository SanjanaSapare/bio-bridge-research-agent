"""JSON caching of completed runs and loading of bundled demonstration examples."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Optional

from config import CACHE_DIR, EXAMPLES_DIR
from schemas import RunResult


def cache_key(problem: str, source_field: str, constraints: str, model: str) -> str:
    raw = "\x1f".join(["v2", problem.strip(), source_field.strip(), constraints.strip(), model.strip()])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


def save_run(result: RunResult, key: str, cache_dir: Path = CACHE_DIR) -> Optional[Path]:
    """Best-effort save; returns None if the disk is read-only (e.g. some hosts)."""
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        path = cache_dir / f"{key}.json"
        path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        return path
    except OSError:
        return None


def load_run(key: str, cache_dir: Path = CACHE_DIR) -> Optional[RunResult]:
    path = cache_dir / f"{key}.json"
    if not path.exists():
        return None
    try:
        return RunResult.model_validate_json(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def list_runs(cache_dir: Path = CACHE_DIR) -> list[dict]:
    """Saved live runs, newest first: [{key, result, mtime}]. Unreadable files are skipped."""
    out: list[dict] = []
    if not cache_dir.exists():
        return out
    for p in cache_dir.glob("*.json"):
        try:
            res = RunResult.model_validate_json(p.read_text(encoding="utf-8"))
            out.append({"key": p.stem, "result": res, "mtime": p.stat().st_mtime})
        except (OSError, ValueError):
            continue
    out.sort(key=lambda d: d["mtime"], reverse=True)
    return out


def delete_run(key: str, cache_dir: Path = CACHE_DIR) -> bool:
    """Remove one saved run. Only plain hex keys are accepted (no path tricks)."""
    if not key or not all(c in "0123456789abcdef" for c in key):
        return False
    try:
        (cache_dir / f"{key}.json").unlink()
        return True
    except OSError:
        return False


def list_examples(examples_dir: Path = EXAMPLES_DIR) -> dict[str, str]:
    """Map example file stem -> display title (the stored problem's first line)."""
    out: dict[str, str] = {}
    if not examples_dir.exists():
        return out
    for p in sorted(examples_dir.glob("*.json")):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            out[p.stem] = data.get("title") or p.stem.replace("_", " ").title()
        except (OSError, ValueError):
            continue
    return out


def load_example(name: str, examples_dir: Path = EXAMPLES_DIR) -> RunResult:
    """Load a bundled demonstration. Always flagged is_demo=True."""
    path = examples_dir / f"{name}.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    data = data.get("result", data)
    result = RunResult.model_validate(data)
    result.is_demo = True
    return result
