"""On-demand, source-grounded metadata checks for Bio-Bridge.

These checks establish record identity/metadata consistency, not scientific truth. Claim excerpts
are checked locally for verbatim presence; semantic entailment is explicitly left unverified.
"""
from __future__ import annotations

from difflib import SequenceMatcher
from typing import Callable
from urllib.parse import quote
import requests

from integrity import verify_quote
from schemas import Paper

ARXIV_API = "https://export.arxiv.org/api/query"
S2_API = "https://api.semanticscholar.org/graph/v1/paper/"


def verify_sources(papers: list[Paper], evaluations: list, timeout: int = 12,
                   http_get: Callable | None = None) -> dict:
    get = http_get or requests.get
    records = []
    title_seen: dict[str, str] = {}
    for p in papers:
        row = {"paper_id": p.paper_id, "title": p.title, "status": "unable_to_verify",
               "checks": [], "details": [], "text_basis": "abstract" if p.abstract else "metadata only"}
        norm = "".join(c.lower() for c in p.title if c.isalnum())
        if norm in title_seen:
            row["checks"].append({"name": "duplicate", "status": "duplicate", "detail": f"Same normalized title as {title_seen[norm]}"})
        else:
            title_seen[norm] = p.paper_id
            row["checks"].append({"name": "duplicate", "status": "unique", "detail": "No duplicate title found in this result set."})
        try:
            if p.arxiv_id:
                resp = get(ARXIV_API, params={"id_list": p.arxiv_id, "max_results": 1}, timeout=timeout)
                if resp.status_code != 200:
                    raise RuntimeError(f"arXiv HTTP {resp.status_code}")
                import xml.etree.ElementTree as ET
                root = ET.fromstring(resp.text)
                ns = {"a": "http://www.w3.org/2005/Atom", "x": "http://arxiv.org/schemas/atom"}
                entry = root.find("a:entry", ns)
                if entry is None:
                    row["checks"].append({"name": "record_lookup", "status": "not_found", "detail": "arXiv returned no record for this identifier."})
                else:
                    remote_title = " ".join((entry.findtext("a:title", "", ns)).split())
                    title_match = SequenceMatcher(None, "".join(remote_title.lower().split()), "".join(p.title.lower().split())).ratio() >= .97
                    row["checks"].append({"name": "title_match", "status": "matched" if title_match else "mismatch", "detail": "Title matches arXiv metadata." if title_match else f"Retrieved title differs: {remote_title}"})
                    row["checks"].append({"name": "record_lookup", "status": "matched", "detail": "Identifier resolves to an arXiv record."})
                    remote_doi = (entry.findtext("x:doi", "", ns) or "").strip()
                    if p.doi and remote_doi:
                        row["checks"].append({"name": "doi_match", "status": "matched" if p.doi.lower() == remote_doi.lower() else "mismatch", "detail": "DOI matches arXiv metadata." if p.doi.lower() == remote_doi.lower() else "DOI differs from arXiv metadata."})
            elif p.paper_id.startswith("s2:"):
                pid = p.paper_id[3:]
                resp = get(S2_API + quote(pid, safe="") , params={"fields": "title,year,authors,externalIds,url"}, timeout=timeout)
                if resp.status_code != 200:
                    raise RuntimeError(f"Semantic Scholar HTTP {resp.status_code}")
                data = resp.json()
                remote_title = (data.get("title") or "").strip()
                match = SequenceMatcher(None, "".join(remote_title.lower().split()), "".join(p.title.lower().split())).ratio() >= .97
                row["checks"].append({"name": "title_match", "status": "matched" if match else "mismatch", "detail": "Title matches Semantic Scholar metadata." if match else f"Retrieved title differs: {remote_title}"})
                row["checks"].append({"name": "record_lookup", "status": "matched", "detail": "Identifier resolves to a Semantic Scholar record."})
            else:
                row["checks"].append({"name": "record_lookup", "status": "unavailable", "detail": "No supported stable identifier is available."})
        except Exception as exc:
            row["checks"].append({"name": "record_lookup", "status": "incomplete", "detail": f"Live lookup failed ({type(exc).__name__}); no source verification claim made."})
        statuses = [c["status"] for c in row["checks"]]
        row["status"] = "verified" if "matched" in statuses and not any(s in statuses for s in ("mismatch", "incomplete", "not_found")) else ("mismatch" if "mismatch" in statuses else "incomplete")
        records.append(row)

    p_by_id = {p.paper_id: p for p in papers}
    claims = []
    for ev in evaluations:
        paper = p_by_id.get(ev.paper_id)
        if not paper:
            continue
        for c in ([ev.paper_objective, ev.paper_method] + list(ev.reported_findings) + list(ev.reported_limitations)):
            if c is None: continue
            matched = verify_quote(c.quote, f"{paper.title}. {paper.abstract}")
            claims.append({"claim": c.statement, "paper_id": paper.paper_id,
                           "status": "excerpt_matched" if matched else "excerpt_not_matched",
                           "excerpt": c.quote if matched else "",
                           "method": "verbatim excerpt comparison",
                           "limitation": "Verbatim presence does not establish that the excerpt logically supports the claim; semantic entailment was not independently verified."})
    counts = {"sources_checked": len(records), "source_records_matched": sum(any(c["name"] == "record_lookup" and c["status"] == "matched" for c in r["checks"]) and not any(c["status"] == "mismatch" for c in r["checks"]) for r in records),
              "claims_assessed": len(claims), "excerpts_matched": sum(c["status"] == "excerpt_matched" for c in claims),
              "excerpts_not_matched": sum(c["status"] == "excerpt_not_matched" for c in claims),
              "semantic_claims_unverified": len(claims)}
    return {"checked_at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"), "summary": counts, "sources": records, "claims": claims,
            "scope_note": "Source identity/metadata checks are separate from scientific correctness. Claim checks here only test whether the cited excerpt appears verbatim in the retrieved abstract; semantic support is not established. Abstracts only were available, not full-paper reviews."}
