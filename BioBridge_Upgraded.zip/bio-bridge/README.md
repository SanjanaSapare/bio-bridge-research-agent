# Bio-Bridge: Cross-Disciplinary Research Matchmaker

Describe a hard problem. Four agents work in sequence:

1. **Abstractor** decomposes it into objective, constraints, variables and underlying mechanisms (independent of
   your discipline) and plans 3 to 6 literature searches, each probing one mechanism or constraint.
2. **Explorer** retrieves **real** papers from arXiv and (optionally) Semantic Scholar, keeping authors, year,
   DOI and arXiv id from the source records, and ranks them locally.
3. **Critic** compares each paper's described mechanism, objective and conditions with your problem, scores five
   criteria, and labels the connection Promising, Promising with modifications, Speculative or Poorly supported.
4. **Translator** turns up to three supported connections into a testable proposal with adaptation, validation
   plan and references built from the retrieved records.

If the research does not support a connection, Bio-Bridge says so instead of producing one.

Stack: Python 3.10 or newer (3.12 or 3.13 recommended), Streamlit, Google Gemini API (official
`google-genai` SDK, free tier), Pydantic, requests, fastembed + NumPy,
python-dotenv. No LangChain, no Ollama, no local LLM, no database, no Anthropic/OpenAI keys.

## Quick start on Windows (one click)

1. Extract the ZIP and open the `bio-bridge` folder.
2. Double-click **`Start_BioBridge.bat`**.
3. First run only: it installs everything, creates `.env`, and opens it in Notepad. Paste your free
   Gemini key after `GEMINI_API_KEY=`, save, close Notepad.
4. Your browser opens at **http://localhost:8501**.

The plain-language version is in `README_START_HERE.txt`. Stop the app with `Ctrl+C` in the launcher
window (answer `Y` if asked to terminate the batch job) or close that window.

What the launcher does: finds Python 3.10+, creates `.venv` if missing, installs `requirements.txt` only
when it changed, creates `.env` from `.env.example` if missing, checks the config without printing your
key, refuses to start a second copy if port 8501 is already in use (it opens the running one), then runs
`.venv\Scripts\python.exe -m streamlit run app.py` bound to `localhost`.

## What you need

| Item | Required? | Used for |
|---|---|---|
| Gemini API key (free, from Google AI Studio) | Required for live runs | LLM calls for Abstractor, Critic, Translator |
| Semantic Scholar API key | Optional | Fewer rate-limit errors |
| arXiv key | Not needed | arXiv's public API needs no key for basic use |

Cached demonstrations (Home or My Projects) need **no keys and no internet**. They appear only if
JSON files are present in `data/examples/`.

## Manual setup (if you prefer the terminal)

```powershell
py -3.13 -m venv .venv            # or: py -m venv .venv
.venv\Scripts\Activate.ps1        # PowerShell; in cmd use .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
copy .env.example .env
notepad .env
streamlit run app.py
```
If PowerShell blocks activation: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`.
If `pip install` fails on a brand-new Python (most likely `fastembed`/`onnxruntime`), use Python 3.12 or 3.13.

## Configuration (`.env`)

```
GEMINI_API_KEY=your-gemini-key
MODEL=gemini-3.5-flash-lite
S2_API_KEY=
```
Optional tuning: `MAX_PAPERS_PER_SEARCH` (8), `RERANK_LIMIT` (15), `SHORTLIST_LIMIT` (5),
`REQUEST_TIMEOUT` (20), `LLM_CONCURRENCY` (1; raise only if your quota allows).
`.env` is git-ignored. Never commit it.

### Free-tier Gemini
Get a key at https://aistudio.google.com/apikey and do not enable billing. Model names change, so
Bio-Bridge never hard-codes one: open https://ai.google.dev/gemini-api/docs/pricing, find a text model
whose Free Tier column says "Free of charge", and put its ID in `MODEL`. When this was last checked,
`gemini-3.5-flash-lite` was listed as free; availability can differ by account, so confirm in AI Studio.
The free tier has per-minute and per-day limits that vary and can change; see
https://ai.google.dev/gemini-api/docs/rate-limits. One full run makes about 7 Gemini calls
(1 Abstractor, up to 5 Critic, 1 Translator; the Translator is skipped when nothing is supported), one at a time. The app reports quota, rate-limit, timeout,
invalid-key and missing-model problems in plain language and never invents papers or citations.
Google notes that free-tier content may be used to improve its products, so do not enter confidential data.

## The interface

Sidebar: Home, New Search, My Projects, Research Library, Settings.

| Screen | What it shows |
|---|---|
| Home | Hero + problem box, example chips, "How it works" (four agents), recent projects, demonstrations |
| New Search | Full form: problem, optional source field and constraints |
| Live progress | Four agent cards with real status (waiting, running, completed, failed); Cancel button |
| Results | On-demand Evidence Verification summary and expandable report, then eight ordered sections: 1 Problem understanding, 2 Cross-domain discoveries (up to three ranked connections), 3 Research evidence (paper card, excerpt checks, extracted mechanism), 4 Why it matches (criteria breakdown), 5 Limitations and transfer risks, 6 Proposed adaptation, 7 Validation plan, 8 References. Text reported by a paper and AI interpretation are labelled separately. |
| Proposal | Executive summary, literature overview, methodology, outcomes, experiments, risks; Edit toggle; Markdown and JSON download |
| My Projects | Saved live runs (open or delete) and bundled demonstrations |
| Research Library | Searchable list of every retrieved paper across saved runs |
| Settings | Config status (key never shown), model, limits, clear saved runs |

Completed live runs are cached in `data/cache/`, so repeating the same input is instant and free.
There is no PDF export (Markdown and JSON only).

## How scoring works
Two different things are shown and they must not be confused:

| Measure | What it is | What it is NOT |
|---|---|---|
| **Retrieval relevance** (embedding similarity) | How close a paper's wording is to the problem. Used only to choose which papers the Critic reads. Optional: if the local model cannot download, papers are read in search order. | Evidence that a mechanism transfers, or that a paper is correct. |
| **Transferability score** (0-10, nearest 0.5) | 30% mechanism + 20% objective + 20% constraints + 15% evidence + 15% adaptation feasibility, judged by the Critic from the abstract and limited by Python. | A probability of success. Similarity is not an input. |

Python rules applied after the model answers:
- Every statement the Critic attributes to a paper (objective, method, findings, limitations) needs a quote that
  is found **word for word** in the retrieved abstract, or it is discarded. (This proves the words exist, not that
  the paper is right.)
- Evidence strength is capped at 7/10 because only abstracts are read, and at 3/10 when no reported finding
  survives verification.
- A label is only ever lowered when the numbers do not justify it (for example "Promising" needs score >= 7.5,
  mechanism >= 7, constraints >= 6 and evidence >= 5). Nothing verifiable means "Speculative" at best.
- A low score does not stop the run: any candidate that is not "Poorly supported" can be carried forward, and the
  proposal is framed as exploratory when the best label is Speculative.

## Evidence verification (on demand)
Use **Verify Evidence** on the results screen to query the relevant live metadata source for each retrieved record: arXiv identifiers are checked against the arXiv Atom API; Semantic Scholar records are checked against its Graph API. The report records lookup outcomes, title matches/mismatches, available DOI checks, duplicate titles within the current result set, and the actual local timestamp. Network/API failures are marked incomplete rather than verified. The detailed report can be expanded or downloaded as JSON.

Claim checks are deliberately narrower than scientific fact-checking: the report tests whether the Critic's cited excerpt appears in the retrieved title/abstract text. An excerpt match does **not** prove that the excerpt logically entails the claim or that the paper's finding is correct; semantic entailment is explicitly marked unverified. The app does not claim to have read full papers when only abstracts were retrieved. Metadata identity and scientific correctness remain separate.

## Run the tests
No API keys or internet needed.
```powershell
python -m unittest discover -s tests -t . -v
```
They cover the pipeline end to end with test doubles (quota and rate-limit errors, source outages,
embedding failure, invented citations, caching), schemas, scoring and parsers.

## Troubleshooting
| Problem | Fix |
|---|---|
| Python not found | Install Python 3.12/3.13 from python.org and tick "Add python.exe to PATH" |
| Package install fails | Check internet/VPN/proxy to pypi.org; avoid very new Python versions |
| "GEMINI_API_KEY is missing" | Edit `.env`, save, restart the app |
| Gemini rejects the key (400/401/403) | Create a new key in AI Studio |
| 404 model not found | Fix `MODEL` using the pricing page |
| Free-tier rate or daily limit (429) | Wait a minute, or use saved runs/demos; daily limits reset later |
| Semantic Scholar 429 | Wait, or add `S2_API_KEY`; arXiv results still work |
| Research retrieval failed | Check internet/VPN/proxy and retry |
| fastembed download error | Needs internet on first run; the app continues and reads papers in search order |
| Port already in use | Another copy is running; the launcher opens it. Or run `streamlit run app.py --server.port 8502` |
| `.env` changes ignored | Stop the app and start it again |

## Deploy (free hosting): Streamlit Community Cloud
Streamlit Community Cloud is the simplest fit for this app, which is a long-running Python/Streamlit
server. (Netlify hosts static sites and serverless functions, so it is not suitable.) Check Streamlit's
current terms and limits before relying on it; free hosting and free API quota are both limited.

1. Push the project to a GitHub repository (see "Keep keys out of GitHub").
2. Go to https://share.streamlit.io, sign in with GitHub, **Create app**, choose the repo, branch `main`,
   main file `app.py`.
3. Under **Advanced settings** choose Python 3.12 or 3.13 and paste your secrets in TOML format:
   ```toml
   GEMINI_API_KEY = "your-gemini-key"
   MODEL = "gemini-3.5-flash-lite"
   S2_API_KEY = ""
   ```
4. Deploy. Edit secrets later in the app's settings. The app reads Streamlit secrets automatically when
   no environment variable is set.

Anyone who can open your app link spends YOUR Gemini free-tier quota, so restrict who can view it if the
platform lets you, or share the repository instead. The first run downloads the embedding model, and the
`data/cache/` folder may not persist between restarts (the app handles this).

## Keep keys out of GitHub
- `.env`, `.env.*` (except `.env.example`) and `.streamlit/secrets.toml` are git-ignored; do not remove them.
- Before your first commit run `git status` and confirm `.env` is **not** listed.
- If a key is ever committed, delete it in Google AI Studio immediately and create a new one; deleting the
  file afterwards does not remove it from git history.

## Project structure
```
bio-bridge/
  Start_BioBridge.bat   one-click Windows launcher
  README_START_HERE.txt beginner quick start
  app.py                Streamlit UI (entry point)
  pipeline.py           sequential four-agent pipeline + status reporting
  config.py             settings from .env / Streamlit secrets
  schemas.py            Pydantic models for every structured output
  llm.py                Gemini wrapper: retries, JSON parsing, validation, repair
  scoring.py            retrieval similarity, weighted transferability score, evidence caps, label guard
  integrity.py          DOI/arXiv id validation, quote verification, citation/link scrubbing
  cache.py              run caching, listing, demonstration loading
  agents/               abstractor.py explorer.py critic.py translator.py
  sources/              arxiv_src.py s2_src.py
  data/examples/        optional cached demonstrations (JSON)
  tests/                fakes.py test_pipeline.py test_schemas.py test_citations.py test_source_verification.py
  source_verification.py live source metadata checks + excerpt audit report
  .streamlit/config.toml  theme
  requirements.txt  .env.example  .gitignore
```

## Known limitations
- Retrieval uses abstracts only; the Critic cannot judge a mechanism more deeply than the abstract allows.
- arXiv search is keyword based and polite-rate-limited, so retrieval takes tens of seconds.
- The transferability score is a ranking aid built from model judgement, not a validated statistic.
- Only abstracts are read. Source verification checks metadata identity and excerpt presence; it does not establish scientific correctness or semantic entailment.
- Metadata (authors, DOI) appears only when the source record has it; otherwise it is shown as unavailable.
- No PDF export (Markdown and JSON only).
